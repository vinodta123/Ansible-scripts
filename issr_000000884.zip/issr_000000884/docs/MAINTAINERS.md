Maintainers
This file lists how this code is maintained. When making changes to the system, this file tells you who needs to review your patch - you need at least one maintainer to approve your pull request. Additionally, you need to not receive a veto from a Lieutenant.

Process
To get your contribution committed to the code, follow the next process:

Contact the AH IT Team trough [mail](@aholddelhaize.com) or open a Jira ticket here.
After you have a ticket, create a branch from the Jira issue you received or created: How to create a branch from a Jira issue
When creating the branch, specify the correct repository and correct branch type (most likely a feature or bugfix).
Work on your code in the branch.
Commit often (so that you don't loose your work).
When finished working on the code, perform a Pull Request How to create a Pull Request.
You need to add at least one of the maintainers of this code as a reviewer.
After the code review is done, you will get an approval, and the maintainer will merge the code.
After several commits we will tag the master branch, so that a new release is available.
Contact Information
To reach out to the team, go to AH IT Team or send us a email on fillmein>@aholddelhaize.com

Lieutenants
Maintainers
https://confluence.ah.nl/display/~4410106891