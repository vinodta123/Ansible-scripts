Playbook to deploy of ISSR
========================================================
#https://confluence.ah.nl/display/COO/ISSR+Design+Draft+-+New


### Files and Playbooks used for ISSR-DCT Deployment
### *site.yml*
Master playbook. This playbook is the starting point to start all sub-playbooks. In this playbook this file imports the following playbooks:
- foundation.yml
- database.yml
- application.yml

The purpose of this master playbook is to run all other playbooks.
### *foundation.yml*
This playbook contains several plays. The first play imports 1 role:
* azure_foundation__ - This role imports other roles to create the following Azure resources for ISSR:
  * Azure Resource Group(s)
  * Azure Storage Account(s)
  * Azure Network Security Group(s)
  * Azure Virtual Subnet(s)
  * Azure Key Vault(s)
  
### *application.yml*
This file executes all the tasks related installaton of tomcat server for the  application configuration.It takes the input from variable file.

### *database.yml*
This file executes all the tasks related installaton of oracle database for the  application configuration.It takes the input from variable file . 

#### *inventories\{{environment_directory}} \all\azure_common.yml*
This file contains the generic variable values needed to create the Azure Resources. These variables are being used to construct several names in other variable files. It also contains the subscription ID of the subscription in which the Azure resources needs to be created. This ID should not be modified, as this is specific to the inventory folder.

#### *inventories\{{environment_directory}} \all\azure_key_vault.yml*
This file contains the generic variable values needed to create:
* Key Vault(s)

#### *inventories\{{environment_directory}} \all\azure_resource_group.yml*
This file contains the generic variable values needed to create:
* Resource Group(s)

#### *inventories\{{environment_directory}} \all\azure_storage_account.yml*
This file contains the generic variable values needed to create the Azure Storage Account Resources and Services.

#### *inventories\{{environment_directory}} \all\azure_network_security_group.yml*
This file contains the generic variable values needed to create the following Azure Networking Resources:
* Virtual Subnet(s)
* Network Security Group(s)


####oracle_database_12c

# Check confluence for size options
# Depends on datadisk size per machine type
# @link https://confluence.ah.nl/display/AIF/Design+Oracle+RDBMS#DesignOracleRDBMS-Storagesetup
# Note, do -1 GB per disk for meta stuff to fit in


#### database.yml

This file contains application configuration tasks for ISSR-Dcz.This will also install middleware roles required for DB VM configuration.

Variation from default values:


####Dev:
================
ORACLE_CHAR_SET: 'AL32UTF8'
oracledb_orareco_size: '628G'
oracledb_oradata_size: '116G'
virtual_machine_managed_disk_type: 'Standard_LRS'

