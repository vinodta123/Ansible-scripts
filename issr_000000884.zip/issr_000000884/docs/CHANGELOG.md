# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased
* Combine server baseline roles into 1 role.
* IAM role for configuring LDAP & AD membership.
---

# Releases
> ## 0.1.0 - 2019-10-15
>## [1.0.0] - 2019-11-07 - v. 496[Confluence Version]
>## [1.0.1] - 2019-11-13 - v. 519[Confluence Version]
>
