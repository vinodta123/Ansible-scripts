# Ansible Role: azure_availability_set

This Ansible Role creates an Azure Availability Set. Please be aware that this role only can be used to deploy at one subscription at a time. If it is needed to deploy to another subscription, then this has to be arranged with the means of targeting your Azure authentication. More information [here](https://docs.ansible.com/ansible/latest/scenario_guides/guide_azure.html). At AH IT we are using a Managed Identity for Azure Resources to authenticate and target a Azure subscription.

# Requirements

This role is meant to be used to provision one or more Availability Set(s) in one of the Azure subscriptions of Albert Heijn.

# Role Variables

## Creating one or more Availability Set(s)
This role takes the following variables for when creating resource groups:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
> `azure_tags`
> * Mandatory: Optional, but will be set automatically if not defined.
> * Type: Dictionary
> * Mandatory Keys & Values:
>    * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>  * Description: This dictionary variable sets mandatory Azure Tags on the Availability Set. If they are not set, then the role will create the `azure_tags` variable automatically. It will be set based on the mandatory keys and values as specified above. If these are not set, then role will fail to run. For more information on the mandatory tags and allowed values click [here](https://confluence.ah.nl/display/ACF/Tags)
>
If the `azure_tags` is not set, then the following variables need to be set, otherwise Azure Policy will block the provisioning of resources:
>   * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)

The next variables determine the resource group:
>`availability_sets`
> - Type: Dictionary
> - Description: This dictionary variable contains a list item for each Availability Set.
>
>  * `availability_set_state`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `present`,`absent`
>    * Default Value: `present`
>    * Description: This value determines the state of the Availability Set. When state is 'present', the Availability Set will be created if not present yet. If absent, it will be removed.
>
>  * `availability_set_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the name of the Availability Set to create. Please check the naming convention here for allowed values: [AH IT Naming Convention](https://confluence.ah.nl/pages/viewpage.action?spaceKey=ACF&title=Naming+Convention#NamingConvention-AzureNetworkSecurityGroupNamingConvention)
>
>  * `availability_set_update_domain_count`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: `1-20`
>    * Default Value: `5`
>    * Description: This variable determines the amount of update domains in one Availability Set. Note, this cannot be changed once the availability set has been created.
>
>  * `availability_set_fault_domain_count`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: `1-3`
>    * Default Value: `3`
>    * Description: This variable determines the amount of fault domains in one Availability Set. Note, this cannot be changed once the availability set has been created.
>
>  * `availability_set_sku`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: `Aligned`,`Classic`
>    * Default Value: Aligned
>    * Description: This variable determines the amount of fault domains in one Availability Set. Note, this cannot be changed once the availability set has been created.

# Examples
An example of above variable `availability_sets` to create multiple network security groups in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create two resource groups.
```yaml
- name: 'Create Availability Sets'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  vars:
    business_unit_name: 'Albert Heijn'
    application_name: 'Simpsons App'
    application_id: 'AP000000000'
    environment_name: 'Development'
    live_status: 'No'
    playbook_version: '0.1.0'
    availability_sets:
      - availability_set_name: 'WeEu-S03-Dev-As-Simp-01'
        availability_set_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
      - availability_set_name: 'NoEu-S03-Dev-As-Simp-01'
        availability_set_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'

  tasks:
    - name: 'Import Azure Availability Set Role'
      include_role:
        name: 'azure_availability_set'
```
## Example 2 - Code Snippet
This will create 2 resource groups including Azure tags that are set on a generic level. The resource groups are getting created in two different regions.

General values that will be used to construct the Azure Tags:
```yaml
azure_tags:
  business_unit_name: 'Albert Heijn'
  application_name: 'Simpsons App'
  application_id: 'AP000000000'
  environment_name: 'Development'
  live_status: 'No'
  playbook_version: '0.1.0'
```
```yaml
availability_sets:
  - availability_set_name: 'WeEu-S03-Dev-Nsg-Simp-01'
    availability_set_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
  - availability_set_name: 'NoEu-S03-Dev-Nsg-Simp-01'
    availability_set_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Preview modules: [GitHub](https://github.com/Azure/azure_preview_modules).

# Author Information

Team: AH IT Cloud Foundation Team
