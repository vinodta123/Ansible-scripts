# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
---

# Releases
## [1.1.6] - 2019-11-06

> ### BugFix
> * [CAP-54](https://jira.ah.nl/browse/CAP-54)
>   * Fix win_uri issue for windows platform.
>
> ## [1.1.5] - 2019-10-10
>
> ### Release
> * [TCSCLDVPS-1600](https://jira.ah.nl/browse/TCSCLDVPS-1600)
> * [TCSCLDVPS-1574](https://jira.ah.nl/browse/TCSCLDVPS-1574)
> * [TCSCLDVPS-1455](https://jira.ah.nl/browse/TCSCLDVPS-1455)
>   * Additional Linux services monitoring through Nagios
> * [TCSCLDVPS-1582](https://jira.ah.nl/browse/TCSCLDVPS-1582)
> * [TCSCLDVPS-1581](https://jira.ah.nl/browse/TCSCLDVPS-1581)
>   * Additional Windows services monitoring through Nagios
>
> ## [1.1.4] - 2019-08-15
>
> ### Custom (Feature)
> * [CAP-51](https://jira.ah.nl/browse/CAP-51)
>   * Nagios Host/Service Config creation & Apply Config commands now run on the machine itself rather than on ansible node / Devops worker.
>   
> ## [1.1.3] - 2019-08-15
> 
> ### BugFix
> * [TCSCLDVPS-1592](https://jira.ah.nl/browse/TCSCLDVPS-1592)
>   * Update outdated nagios repo.
>
> ## [1.1.2] - 2019-08-15
>
> ### Custom (BugFix & Feature)
> * [CAP-50](https://jira.ah.nl/browse/CAP-50)
>   * Apply config now runs only once after service registration of all hosts.
>   * Added a pause/sleep of 15 sec after host registration to give nagios enough time to apply config.
>   * Adding "always" tags for setting default value and default checks
>   * Added JAR file plugin support for linux ncpa agent.
>
> ## [1.1.1] - 2019-07-26
>
> ### Fixed
> * [CAP-46](https://jira.ah.nl/browse/CAP-46)
>   * Fixed issue for fetching IP address for Windows servers.
>   * Fixed template for disabling passive handlers.
>
> ## [1.1.0] - 2019-07-17
>
> ### Changed
> * [CAP-33](https://jira.ah.nl/browse/CAP-42)
>   * Added Default values for each environment.
>   * Fixed issue related to Disk Checks.
>   * Added Server icon while registering the hosts.
>   * Removed NRDP config (passive checks).
>   * Enabled active checks.
>
> ## [1.0.0] - 2019-06-05
>
> ### Added 
> * [TCSCLDVPS-609](https://jira.ah.nl/browse/TCSCLDVPS-609) - Initial version
