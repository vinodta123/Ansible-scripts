# Maintainers

This file lists how this code is maintained. When making changes to the system, this file tells you who needs to review your patch - you need at least one maintainer to approve your pull request. Additionally, you need to not receive a veto from a Lieutenant.

## Process
To get your contribution commited to the code, follow the next process:

1. Contact the AH IT Cloud Foundation Team trough [mail](ah-it.cloud.team@aholddelhaize.com) or open a Jira ticket [here](https://jira.ah.nl/secure/RapidBoard.jspa?rapidView=859).
2. After you have a ticket, create a branch from the Jira issue you received or created: [How to create a branch from a Jira issue](https://confluence.atlassian.com/bitbucket/branching-a-repository-223217999.html#BranchingaRepository-jirabranchTocreateabranchfromanissueinJiraSoftware)
3. When creating the branch, specify the correct repository and correct branch type (most likely a feature or bugfix).
4. Work on your code in the branch.
5. Commit often (so that you don't loose your work).
6. When finished working on the code, perform a Pull Request [How to create a Pull Request](https://confluence.atlassian.com/bitbucket/create-a-pull-request-to-merge-your-change-774243413.html).
7. You need to add at least one of the maintainers of this code as a reviewer.
8. After the code review is done, you will get an approval, and the maintainer will merge the code.
9. After several commits we will tag the master branch, so that a new release is available.

## Contact Information

To reach out to the team, go to [AH IT Azure Cloud Foundation Team](https://confluence.ah.nl/spaces/viewspace.action?key=ACF) or send us a email on ah-it.cloud.team@aholddelhaize.com

### Lieutenants

* [Frank Valkenburg](https://confluence.ah.nl/display/~4410100059)
* [Richard Waal](https://confluence.ah.nl/display/~4410105871)

### Maintainers

* [Richard Waal](https://confluence.ah.nl/display/~4410105871)