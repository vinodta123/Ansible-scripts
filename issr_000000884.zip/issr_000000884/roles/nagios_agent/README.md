Ansible Role - Nagios Agent
=========

This Ansible Role takes care of the following:

* Installs and configures the NCPA client software
* Registers the client with the Nagios server
* Configures some default monitoring checks
* Adds the host to a host group in Nagios

If custom checks are required, it's currently the responsibility of the respective team to install and configure the checks in their Ansible Playbook. 

Requirements
------------

The Ansible Control Node needs to be MSI enabled and needs to have the correct access to the Azure Key Vault in which the API secret key is located of the Nagios environment. The Ansible Control Node also needs to be able to communicate with the Nagios server over tcp port 443. 

## Operating systems
This role will work on the following operating systems:

 * Red Hat Enterprise Linux 7.x
 * Windows Server 2012 R2, 2016, 2019


# Role Variables

## Generic Variables

> `nagios_agent_hostgroup_name`
>  * Mandatory: `true`
>  * Type: `String`
>  * Accepted Values: `HG-Linux-Az-Prd`, `HG-Linux-Az-Acc`, `HG-Linux-Az-Tst`, `HG-Linux-Az-Dev`, `HG-Windows-Az-Prd`, `HG-Windows-Az-Acc`, `HG-Windows-Az-Tst`, `HG-Windows-Az-Dev`
>  * Default Value: none
>  * Description: This determines the Host Group in Nagios that the host will be placed in. 
>
> `nagios_agent_server_uri`
>  * Mandatory: `false`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: `https://nagios.ah.nl`
>  * Description: This value determines the Nagios environment the host is registered in.
>
> `nagios_agent_server_api_key`
>  * Mandatory: `false`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: API key for Nagios Production, retrieved from Azure Key Vault.
>  * Description: This value contains the API key that's used for registering the client and monitoring services to the Nagios server. By default it's populated with the API key for the Production Nagios environment. If another custom Nagios server is being used, as indicated in the `nagios_agent_server_uri` variable, the corresponding API key must be provided.

## Windows
This role takes the following variables for when configuring the Nagios agent on Windows:
> `nagios_agent_windows_services`
> - Mandatory: false
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for monitoring checks that needs to be configured.
>
>  * `service_name`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value contains the name of the monitoring check.
>
>  * `service_check_command`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This determines the Check Command and any command arguments where applicable. For example `check_xi_ncpa!-t {{ nagios_agent_server_api_key }} -P 5666 -M memory/virtual -w 85 -c 95 -q 'units=Gi'`. You also need to change the value if you want to change the behaviour of the default checks, as stated in the /defaults/main.yml file. Consult the Nagios documentation for more information.

## Linux
This role takes the following variables for when configuring the Nagios agent on Linux:
> `nagios_agent_linux_services`
> - Mandatory: false
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for monitoring checks that needs to be configured.
>
>  * `service_name`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value contains the name of the monitoring check.
>
>  * `service_check_command`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This determines the Check Command and any command arguments where applicable. For example `check_xi_ncpa!-t {{ nagios_agent_server_api_key }} -P 5666 -M memory/virtual -w 85 -c 95 -q 'units=Gi'`. You also need to change the value if you want to change the behaviour of the default checks, as stated in the /defaults/main.yml file. Consult the Nagios documentation for more information.


# Dependencies

There are no dependencies on other roles.

# Author Information

Team: AH IT Cloud Foundation Team