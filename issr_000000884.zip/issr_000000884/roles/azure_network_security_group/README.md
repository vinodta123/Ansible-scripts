# Ansible Role: azure_network_security_group

This Ansible Role creates an Azure Network Security Group. Please be aware that this role only can be used to deploy at one subscription at a time. If it is needed to deploy to another subscription, then this has to be arranged with the means of targeting your Azure authentication. More information [here](https://docs.ansible.com/ansible/latest/scenario_guides/guide_azure.html). At AH IT we are using a Managed Identity for Azure Resources to authenticate and target a Azure subscription.

# Requirements

This role is meant to be used to provision one or more Network Security Group(s) in one of the Azure subscriptions of Albert Heijn.

# Role Variables

## Creating one or more Network Security Group(s)
This role takes the following variables for when creating resource groups:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
> `azure_tags`
> * Mandatory: Optional, but will be set automatically if not defined.
> * Type: Dictionary
> * Mandatory Keys & Values:
>    * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>  * Description: This dictionary variable sets mandatory Azure Tags on the Network Security Group. If they are not set, then the role will create the `azure_tags` variable automatically. It will be set based on the mandatory keys and values as specified above. If these are not set, then role will fail to run. For more information on the mandatory tags and allowed values click [here](https://confluence.ah.nl/display/ACF/Tags)
>
If the `azure_tags` is not set, then the following variables need to be set, otherwise Azure Policy will block the provisioning of resources:
>   * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)

The next variables determine the resource group:
>`network_security_groups`
> - Type: Dictionary
> - Description: This dictionary variable contains a list item for each Network Security Group.
>
>  * `network_security_group_state`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: present,absent
>    * Default Value: present
>    * Description: This value determines the state of the Network Security Group. When state is 'present', the Network Security Group will be created if not present yet. If absent, it will be removed.
>
>  * `network_security_group_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the name of the Network Security Group to create. Please check the naming convention here for allowed values: [AH IT Naming Convention](https://confluence.ah.nl/pages/viewpage.action?spaceKey=ACF&title=Naming+Convention#NamingConvention-AzureNetworkSecurityGroupNamingConvention)
>
>  * `network_security_group_resource_group_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the name of the Resource Group in which to create the Network Security Group.
>
> * `network_security_group_port_rules`
>   * Mandatory: true
>   * Type: Dictionary
>   * Description: This variable determines the Network Security Group Port Rules. Please note that any rules not in code will be removed from the Network Security Group. Check [this](https://docs.ansible.com/ansible/latest/modules/azure_rm_securitygroup_module.html#parameters) page for the specific parameters that this variable requires (check the parameter rules; we just gave the parameter another name). Please check the [naming convention](https://confluence.ah.nl/pages/viewpage.action?spaceKey=ACF&title=Naming+Convention#NamingConvention-AzureNetworkSecurityGroupPortRulesNamingConvention) for how to name the specific port rules.
>
>  * `network_security_group_network_resource_group_name`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: When a Network Security Group needs to be removed, then this variable needs to be specified. It contains the name of the resource group in which the Virtual Network has been created. This Virtual Network contains the subnet, on which the Network Security Group has been attached.
>
>  * `network_security_group_virtual_network_name`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: When a Network Security Group needs to be removed, then this variable needs to be specified. It contains the name of the Virtual Network in which the subnet has been created, on which the Network Security Group has been attached.
>
>  * `network_security_group_virtual_subnet_name`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: When a Network Security Group needs to be removed, then this variable needs to be specified. It contains the name of the subnet, on which the Network Security Group has been attached.
>

# Examples
An example of above variable `network_security_groups` to create multiple network security groups in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create two resource groups.
```yaml
- name: 'Create Network Security Groups'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  vars:
    business_unit_name: 'Albert Heijn'
    application_name: 'Simpsons App'
    application_id: 'AP000000000'
    environment_name: 'Development'
    live_status: 'No'
    playbook_version: '0.1.0'
    network_security_groups:
      - network_security_group_name: 'WeEu-S03-Dev-Nsg-Simp-01'
        network_security_group_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
        network_security_group_port_rules:
          - name: 'Deny-Any-To-Any'
            access: 'Deny'
            priority: 4096
            direction: 'Inbound'
          - name: "Allow-Step-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.232.0.32/27]
            destination_address_prefix: '*'
            destination_port_range: ['22','443','3389','80']
            access: 'Allow'
            priority: 3000
            direction: 'Inbound'
          - name: "Allow-Anse-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.232.82.0/28]
            destination_address_prefix: '*'
            destination_port_range: ['22','5985','5986']
            access: 'Allow'
            priority: 3001
            direction: 'Inbound'
          - name: "Allow-Anst-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.232.2.96/28]
            destination_address_prefix: '*'
            destination_port_range: ['22','5985','5986']
            access: 'Allow'
            priority: 3002
            direction: 'Inbound'
          - name: "Allow-AHIT-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.41.0.0/16,10.93.0.0/16,10.137.0.0/16,141.93.0.0/16,10.236.0.32/27]
            destination_address_prefix: '*'
            destination_port_range: ['22','5985','5986','80','443']
            access: 'Allow'
            priority: 2000
            direction: 'Inbound'
      - network_security_group_name: 'NoEu-S03-Dev-Nsg-Simp-01'
        network_security_group_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
        network_security_group_port_rules:
          - name: 'Deny-Any-To-Any'
            access: 'Deny'
            priority: 4096
            direction: 'Inbound'
          - name: "Allow-Step-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.232.0.32/27]
            destination_address_prefix: '*'
            destination_port_range: ['22','443','3389','80']
            access: 'Allow'
            priority: 3000
            direction: 'Inbound'
          - name: "Allow-Anse-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.232.82.0/28]
            destination_address_prefix: '*'
            destination_port_range: ['22','5985','5986']
            access: 'Allow'
            priority: 3001
            direction: 'Inbound'
          - name: "Allow-Anst-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.232.2.96/28]
            destination_address_prefix: '*'
            destination_port_range: ['22','5985','5986']
            access: 'Allow'
            priority: 3002
            direction: 'Inbound'
          - name: "Allow-AHIT-To-Anse-Multi"
            protocol: 'Tcp'
            source_address_prefix: [10.41.0.0/16,10.93.0.0/16,10.137.0.0/16,141.93.0.0/16,10.236.0.32/27]
            destination_address_prefix: '*'
            destination_port_range: ['22','5985','5986','80','443']
            access: 'Allow'
            priority: 2000
            direction: 'Inbound'

  tasks:
    - name: 'Import Azure Network Security Group Role'
      include_role:
        name: 'azure_network_security_group'
```
## Example 2 - Code Snippet
This will create 2 Network Security Groups including Azure tags that are set on a generic level. The Network Security Groups are getting created in two different regions.

General values that will be used to construct the Azure Tags:
```yaml
azure_tags:
  business_unit_name: 'Albert Heijn'
  application_name: 'Simpsons App'
  application_id: 'AP000000000'
  environment_name: 'Development'
  live_status: 'No'
  playbook_version: '0.1.0'
```
```yaml
network_security_groups:
  - network_security_group_name: 'WeEu-S03-Dev-Nsg-Simp-01'
    network_security_group_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
  - network_security_group_name: 'NoEu-S03-Dev-Nsg-Simp-01'
    network_security_group_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
```

## Example 3 - Code Snippet
This will remove 2 Network Security Groups. The Network Security Groups are getting removed from two different regions.

```yaml
network_security_groups:
  - network_security_group_name: 'WeEu-S03-Dev-Nsg-Simp-01'
    network_security_group_state: 'absent'
    network_security_group_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
    network_security_group_network_resource_group_name: 'WeEu-S03-Dev-Rsg-Ntwk-01'
    network_security_group_virtual_network_name: 'WeEu-S03-Dev-Vnet-01'
    network_security_group_virtual_subnet_name: 'WeEu-S03-Dev-Vnet-Snt-Simp-01'
  - network_security_group_name: 'NoEu-S03-Dev-Nsg-Simp-01'
    network_security_group_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
    network_security_group_state: 'absent'
    network_security_group_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
    network_security_group_network_resource_group_name: 'NoEu-S03-Dev-Rsg-Ntwk-01'
    network_security_group_virtual_network_name: 'NoEu-S03-Dev-Vnet-01'
    network_security_group_virtual_subnet_name: 'NoEu-S03-Dev-Vnet-Snt-Simp-01'
```
# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Preview modules: [GitHub](https://github.com/Azure/azure_preview_modules).

# Author Information

Team: AH IT Cloud Foundation Team
