# Ansible Role: Oracle Client (Linux)

- [Ansible Role: Oracle Client](#ansible-role-oracle_client)

# About this role
This Ansible Role configures the following items:

__Linux__:
* Install Pre-requisite packages
* Create user and groups
* Create Logical Volume / Volume Group / File System & Mount File System
* Silent Installation



> `Oracle Client is installed on backend Servers as client utiities are used by the components to connect to Databases.`

# Role Variables (Linux)

### Oracle Client Variables (Linux)

> * `oclient_linux_package`
>   * Mandatory: `true`   (Need to be specificed under playbook only in case if Oracle Client binary is located under a unique / different path then default location)
>   * Type: String
>   * Description: Path of the oracle client Package..For Azure Devops value for the variable will be package name (12102_oracleclient.zip).. Defualt value set is /mnt/library/software/oracle/12102_oracleclient.zip (Ansible Host)

requirements.yml
----------------
Add the oracle_client Repository to your requirements.yml
```yml
- src: 'git+ssh://git@bitbucket-lan.ah.nl:7999/aifr/oracle_client.git'
  name: oracle_client
  version: 1.0.1

servers.yml
-----------
Add import role `oracle_client` to your servers.yml under the section configuring Linux  servers.
```yml
# In the following play we're configuring the group 'linux'.
- name: 'Configure the Linux servers'
  hosts: 'linux'
  become: 'yes'
  tasks:

    - name: 'Importing Server Baseline Configuration Role'
      include_role:
        name: 'azure_compute_baseline'
      tags:
        - 'configure_linux'

    - name: 'Importing the Oracle Client Role'
      import_role:
        name: 'oracle_client'


```yaml

---

# Author Information

- Name: Nelesh Goel
- Email: nelesh.goel.nelesh.goel@ah.nl / nelesh.goel@dxc.com