# Ansible Role: azure_foundation

This Ansible Role imports all AH IT's Azure Roles for creating all foundation resources beside Virtual Machines.
The purpose of this role is to function as a wrapper to run the specific roles when needed.
It is meant to be used in combination with a playbook.

# Requirements

n/a

# Role Variables

This role does not take variables itself.

# Examples
This example creates the following Azure Resources:
* Azure Resource Group(s)
* Azure Storage Account(s)
* Azure Network Security Group(s)
* Azure Virtual Subnet(s)
* Azure Load Balancer(s)
* Azure Key Vault(s)
* Azure Application Security Group(s)

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create the foundation. Variables are loaded by an inventory.
```yaml
- name: 'Creating/Updating Azure Foundation Resources'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: "{{ subscription_id }}"
  tags:
    - 'foundation'
  tasks:
    - name: 'Importing Azure Foundation Role'
      import_role:
        name: 'azure_foundation'
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_preview_modules).

# Author Information

Team: AH IT Cloud Foundation Team
