# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
* Nothing planned
---

# Releases
> ## [1.1.1] - 2019-04-03
>
> ### Changed
> * [TCSCLDVPS-1009](https://jira.ah.nl/browse/TCSCLDVPS-1009) - Changed order of creation of Application Security Groups and Network Security Groups
>
> ## [1.1.0] - 2019-03-19
>
> ### Added
> * [TCSCLDVPS-613](https://jira.ah.nl/browse/TCSCLDVPS-613) - Added Application Security Group Role
>
> ## [1.0.0] - 2019-02-26
>
> ### Added
> * [TCSCLDVPS-637](https://jira.ah.nl/browse/TCSCLDVPS-637) - Initial Release

[Unreleased]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_foundation/compare/diff?targetBranch=refs%2Ftags%2Fv1.1.1&sourceBranch=refs%2Fheads%2Fmaster&targetRepoId=877
[1.0.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_foundation/browse?at=refs%2Ftags%2Fv1.0.0
[1.1.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_foundation/browse?at=refs%2Ftags%2Fv1.1.0
[1.1.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_foundation/browse?at=refs%2Ftags%2Fv1.1.1
