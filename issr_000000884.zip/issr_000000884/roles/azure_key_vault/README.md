# Ansible Role: azure_key_vault

This Ansible Role creates an Azure Key Vault.

# Requirements

This role is ment to be used to provision one or more Key Vault(s) in one of the Azure subscriptions of Albert Heijn.

# Role Variables

This role takes the following variables for when creating Key Vaults:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
> `azure_tags`
> * Mandatory: Optional, but will be set automatically if not defined.
> * Type: Dictionary
> * Mandatory Keys & Values:
>    * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>  * Description: This dictionary variable sets mandatory Azure Tags on the Availability Set. If they are not set, then the role will create the `azure_tags` variable automatically. It will be set based on the mandatory keys and values as specified above. If these are not set, then role will fail to run. For more information on the mandatory tags and allowed values click [here](https://confluence.ah.nl/display/ACF/Tags)
>
If the `azure_tags` is not set, then the following variables need to be set, otherwise Azure Policy will block the provisioning of resources:
>   * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)

>`key_vaults`
> - Type: Dictionary
> - Description: This dictionary variable contains a list item for each key vault.
>
>  * `key_vault_name`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: present,absent
>    * Default Value: present
>    * Description: This variable determines the name of the Key Vault to create. Please check the naming convention here for allowed values: [AH IT Naming Convention](https://confluence.ah.nl/display/ACF/Naming+Convention#NamingConvention-AzureResourcesNamingConvention(notincludingstorageaccounts&virtualmachines)
>
>  * `key_vault_state`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `present`, `absent`
>    * Default Value: `present`
>    * Description: This value determines the state of the Key Vault. When state is 'present', the Key Vault will be created if not present yet. If absent, it will be removed.
>
>  * `key_vault_resource_group_name`
>   * Mandatory: `true`
>   * Type: String
>   * Accepted Values: `westeurope`, `northeurope`
>   * Description: This variable determines the resource group which the Key Vault will be created.
>
>  * `key_vault_enable_soft_delete`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: Property to specify whether soft delete is enabled on the key vault.
>
>  * `key_vault_enabled_for_deployment`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: Property to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault.
>
>  * `key_vault_enabled_for_disk_encryption`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: Property to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys.
>
>  * `key_vault_enabled_for_template_deployment`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: Property to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault.
>
>  * `key_vault_vault_tenant`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `a6b169f1-592b-4329-8f33-8db8903003c7`
>    * Default Value: `a6b169f1-592b-4329-8f33-8db8903003c7`
>    * Description: The Azure Active Directory tenant ID that should be used for authenticating requests to the key vault.
>
>  * `key_vault_sku_name`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `standard`, `premium`
>    * Default Value: `standard`
>    * Description: SKU name to specify whether the key vault is a standard vault or a premium vault.
>
>  * `key_vault_sku_family`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `A`
>    * Default Value: `A`
>    * Description: SKU family name.
>
>  * `key_vault_custom_access_policy`
>    * Mandatory: `false`
>    * Type: Dictionary
>    * Default Value: `none`
>    * Description: This parameter contains a list of the access policies on the Key Vault.
>    * `object_id`
>      * Mandatory: `true`
>      * Type: String
>      * Accepted Values: free form
>      * Default Value: `none`
>      * Description: This parameter contains the object ID of the account/group that needs to have access.
>    * `certificates`
>      * Mandatory: `false`
>      * Type: String
>      * Accepted Values: Check the values to use here: [link](https://docs.ansible.com/ansible/latest/modules/azure_rm_keyvault_module.html#parameters)
>      * Default Value: `none`
>      * Description: This parameter contains the object ID of the account/group that needs to have access.
>    * `keys`
>      * Mandatory: `true`
>      * Type: String
>      * Accepted Values: Check the values to use here: [link](https://docs.ansible.com/ansible/latest/modules/azure_rm_keyvault_module.html#parameters)
>      * Default Value: `none`
>      * Description: This parameter contains the object ID of the account/group that needs to have access.
>    * `secrets`
>      * Mandatory: `true`
>      * Type: String
>      * Accepted Values: Check the values to use here: [link](https://docs.ansible.com/ansible/latest/modules/azure_rm_keyvault_module.html#parameters)
>      * Default Value: `none`
>      * Description: This parameter contains the object ID of the account/group that needs to have access.

# Examples
An example of above variable `availability_sets` to create multiple network security groups in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create two resource groups.
```yaml
- name: 'Create Key Vault(s)'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  vars:
    business_unit_name: 'Albert Heijn'
    application_name: 'Simpsons App'
    application_id: 'AP000000000'
    environment_name: 'Development'
    live_status: 'No'
    playbook_version: '0.1.0'
    key_vaults:
      - key_vault_name: 'WeEu-S03-Dev-Kv-Simp-01'
        key_vault_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
      - key_vault_name: 'NoEu-S03-Dev-Kv-Simp-01'
        key_vault_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'

  tasks:
    - name: 'Import Azure Key Vault Role'
      include_role:
        name: 'azure_key_vault'
```
## Example 2 - Code Snippet
This will create 2 key vaults including Azure tags that are set on a generic level. The key vaults are getting created in two different regions.

General values that will be used to construct the Azure Tags:
```yaml
azure_tags:
  business_unit_name: 'Albert Heijn'
  application_name: 'Simpsons App'
  application_id: 'AP000000000'
  environment_name: 'Development'
  live_status: 'No'
  playbook_version: '0.1.0'
```
```yaml
key_vaults:
  - key_vault_name: 'WeEu-S03-Dev-Kv-Simp-01'
    key_vault_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
  - key_vault_name: 'NoEu-S03-Dev-Kv-Simp-01'
    key_vault_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
```

## Example 3 - Create Key Vaults in different locations
An example of above dictionary variable `key_vaults` to create multiple Key Vaults in different locations:
```
key_vaults:
  - key_vault_name: 'WeEu-S03-Dev-Kv-Simp-01'
    key_vault_state: 'present'
    key_vault_resource_group_location: 'westeurope'
  - key_vault_name: 'NoEu-S03-Dev-Kv-Simp-01'
    key_vault_state: 'present'
    key_vault_resource_group_location: 'northeurope'
```

## Example 4 - Add custom access policy to the Key Vault
An example of how to add `key_vault_custom_access_policy` to the key vault:
In this example we add the object ID of a MSI of a Ansible Control Node Virtual Machine. (weeus01planse03)
In this way the Ansible Control Node can retrieve secrect from the key vault.
```
key_vaults:
  - key_vault_name: 'WeEu-S03-Dev-Kv-Simp-01'
    key_vault_state: 'present'
    key_vault_resource_group_location: 'westeurope'
    key_vault_custom_access_policy: 
    - object_id: 'db90d3f0-2e18-4461-b314-4a35bc251ee6'
      secrets:
        - 'get'
        - 'list'
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_modules).

# Author Information

Team: AH IT Cloud Foundation Team
