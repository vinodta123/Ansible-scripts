# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
* [TCSCLDVPS-973](https://jira.ah.nl/browse/TCSCLDVPS-973) - Corrected GALL&GALL Assertion to Gall & Gall
---

# Releases

>## [1.1.0] - 2019-08-27
>
>### Added
>* [TCSCLDVPS-1317] (https://jira.ah.nl/browse/TCSCLDVPS-1317) - Added additional business units in assertion
>* [TCSCLDVPS-1319] (https://jira.ah.nl/browse/TCSCLDVPS-1319) - Added AE application ids in assertion
>
> ## [1.0.0] - 2019-02-27
>
> ### Added
>

[Unreleased]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_key_vault/compare/diff?targetBranch=refs%2Ftags%2F1.1.0&sourceBranch=refs%2Fheads%2Fmaster&targetRepoId=118
[1.0.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_key_vault/browse?at=refs%2Ftags%2F1.0.0
[1.1.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_key_vault/browse?at=refs%2Ftags%2F1.1.0
