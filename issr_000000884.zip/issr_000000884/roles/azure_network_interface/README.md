# Ansible Role: azure_network_interface

This Ansible Role creates an Azure Network Interface. Please be aware that this role only can be used to deploy at one subscription at a time. If it is needed to deploy to another subscription, then this has to be arranged with the means of targeting your Azure authentication. More information [here](https://docs.ansible.com/ansible/latest/scenario_guides/guide_azure.html). At AH IT we are using a Managed Identity for Azure Resources to authenticate and target a Azure subscription.

# Requirements

This role is meant to be used to provision one or more Network Interface(s) in one of the Azure subscriptions of Albert Heijn.

# Role Variables

## Creating one or more Network Interface(s)
This role takes the following variables for when creating resource groups:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
> `azure_tags`
> * Mandatory: Optional, but will be set automatically if not defined.
> * Type: Dictionary
> * Mandatory Keys & Values:
>    * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>  * Description: This dictionary variable sets mandatory Azure Tags on the Network Interface. If they are not set, then the role will create the `azure_tags` variable automatically. It will be set based on the mandatory keys and values as specified above. If these are not set, then role will fail to run. For more information on the mandatory tags and allowed values click [here](https://confluence.ah.nl/display/ACF/Tags)
>
If the `azure_tags` is not set, then the following variables need to be set, otherwise Azure Policy will block the provisioning of resources:
>   * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)

The next variables determine the resource group:
>`network_interfaces`
> - Type: Dictionary
> - Description: This dictionary variable contains a list item for each Network Interface.
>
>  * `network_interface_state`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `present`, `absent`
>    * Default Value: `present`
>    * Description: This value determines the state of the Network Interface. When state is 'present', the Network Interface will be created if not present yet. If absent, it will be removed.
>
>  * `network_interface_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the name of the Network Interface to create. Please check the naming convention here for allowed values: [AH IT Naming Convention](https://confluence.ah.nl/display/ACF/Naming+Convention#NamingConvention-AzureVirtualNetworkInterfacesNamingConvention)
>
>  * `network_interface_dns_view`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `Internal`, `External`
>    * Default Value: `Internal`
>    * Description: This variable determines Infoblox view in which the DNS host record has to be created.
>
>  * `network_interface_dns_suffix`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: `shd.eu.aholddelhaize.com`, `dl.eu.aholddelhaize.com`, `ah.eu.aholddelhaize.com`,`et.eu.aholddelhaize.com`, `gg.eu.aholddelhaize.com`, `shd.eu.aholddelhaize.com`, `ah.nl`, `ahold.nl`, `ahold.com`, `etos.nl`, `gall.nl`
>    * Default Value: none
>    * Description: This variable determines the DNS zone in which the Infoblox host record needs to be created.
>
>  * `network_interface_resource_group_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the resource group in which the Network Interface has to be created.
>
>  * `network_interface_virtual_network_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the virtual network that contains the subnet that the Network Interface needs to be connected to. This parameter also requires that the variable `subscription_id` is being set, but in general this variable will be set when this role is used from a playbook.
>
>  * `network_interface_virtual_subnet_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the virtual subnet to which the Network Interface needs to be connected to.
>
>  * `network_interface_accelerated_networking_enabled`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable determines if accelerated network should be enabled on the Network Interface. Note that this is only possible on certain Virtual Machine sizes. By default this value is enabled. If you use a Virtual Machine size that doesn't support this, you should set this value to `false`. Virtual Machine sizes that support this, can be found here: [link](https://docs.microsoft.com/en-us/azure/virtual-network/create-vm-accelerated-networking-powershell#limitations-and-constraints).
>
>  * `network_interface_private_ip_address`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the private IP address. If not set then a private IP address will be generated.
>
>  * `network_interface_private_ip_allocation_method`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `Dynamic`
>    * Description: This variable determines the private IP address allocation method.
>
>  * `network_interface_load_balancer_backend_address_pools`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the list of an existing load-balancer backend address pool id to associate with the network interface.
>
>  * `network_interface_application_security_groups`
>    * Mandatory: false
>    * Type: `Dictionary`
>    * Accepted Values: `List`
>    * Default Value: none
>    * Description: This variable determines the list of application security group(s). Each list item is a dict with 2 parameters; resource_group in which the application security group is located and the name of the application security group. See the examples on how to use this.

# Examples
An example of above variable `network_interfaces` to create multiple Network Interfaces in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create two resource groups.
```yaml
- name: 'Create Network Interface(s)'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  vars:
    business_unit_name: 'Albert Heijn'
    application_name: 'Simpsons App'
    application_id: 'AP000000000'
    environment_name: 'Development'
    live_status: 'No'
    playbook_version: '0.1.0'
    subscription_id: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
    network_interfaces:
      - network_interface_name: 'weeus03dlsimp01-nic-01'
        network_interface_dns_suffix: 'shd.eu.aholddelhaize.com'
        network_interface_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
        network_interface_network_resource_group_name: 'WeEu-S03-Dev-Rsg-Ntwk-01'
        network_interface_virtual_network_name: 'WeEu-S03-Dev-Vnet-01'
        network_interface_virtual_subnet_name: 'WeEu-S03-Dev-Vnet-Snt-Simp-01'
        network_interface_application_security_groups:
          - name: 'WeEu-S03-Dev-Asg-Simp-01'
            resource_group: 'WeEu-S03-Dev-Rsg-Ntwk-01'
      - network_interface_name: 'noeus03dlsimp01-nic-01'
        network_interface_dns_suffix: 'shd.eu.aholddelhaize.com'
        network_interface_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
        network_interface_network_resource_group_name: 'NoEu-S03-Dev-Rsg-Ntwk-01'
        network_interface_virtual_network_name: 'NoEu-S03-Dev-Vnet-01'
        network_interface_virtual_subnet_name: 'NoEu-S03-Dev-Vnet-Snt-Simp-01'
        network_interface_application_security_groups:
          - name: 'WeEu-S03-Dev-Asg-Simp-01'
            resource_group: 'WeEu-S03-Dev-Rsg-Ntwk-01'

  tasks:
    - name: 'Import Azure Network Interface Role'
      include_role:
        name: 'azure_network_interface'
```
## Example 2 - Code Snippet
This will create 2 resource groups including Azure tags that are set on a generic level. The resource groups are getting created in two different regions.

General values that will be used to construct the Azure Tags:
```yaml
azure_tags:
  business_unit_name: 'Albert Heijn'
  application_name: 'Simpsons App'
  application_id: 'AP000000000'
  environment_name: 'Development'
  live_status: 'No'
  playbook_version: '0.1.0'
```
```yaml
network_interfaces:
  - network_interface_name: 'weeus03dlsimp01-datadisk-01'
    network_interface_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
    network_interface_attached_to: 'weeus03dlsimp01'
  - network_interface_name: 'noeus03dlsimp01-datadisk-01'
    network_interface_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'
    network_interface_attached_to: 'noeus03dlsimp01'
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Preview modules: [GitHub](https://github.com/Azure/azure_preview_modules).

# Author Information

Team: AH IT Cloud Foundation Team
