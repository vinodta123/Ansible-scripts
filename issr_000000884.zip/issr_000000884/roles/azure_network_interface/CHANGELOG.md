# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
Nothing Planned.
---

# Releases

> ## [1.3.0] - 2019-08-27
>
> ### Added
> * [TCSCLDVPS-1317] (https://jira.ah.nl/browse/TCSCLDVPS-1317) - Added additional business units in assertion
> * [TCSCLDVPS-1319] (https://jira.ah.nl/browse/TCSCLDVPS-1319) - Added AE application ids in assertion

> ## [1.2.0] - 2019-05-06
>
> ### Changed
> * [TCSCLDVPS-1055](https://jira.ah.nl/browse/TCSCLDVPS-1055) - Enabled Network Acceleration by Default
>
> ## [1.1.1] - 2019-03-22
>
> ### Changed
> * [TCSCLDVPS-968](https://jira.ah.nl/browse/TCSCLDVPS-968) - Fixed default filter on application_security_group parameter.
>
> ### Fixed
> * [TCSCLDVPS-973](https://jira.ah.nl/browse/TCSCLDVPS-973) - Corrected GALL&GALL Assertion to Gall & Gall
>
> ## [1.1.0] - 2019-03-19
>
> ### Added
> * [TCSCLDVPS-613](https://jira.ah.nl/browse/TCSCLDVPS-613) - Added Application Security Group Parameter.
>
> ## [1.0.0] - 2019-02-26
>
> ### Added
> * [TCSCLDVPS-637](https://jira.ah.nl/browse/TCSCLDVPS-637) - Initial Release

[Unreleased]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_network_interface/compare/diff?targetBranch=refs%2Ftags%2F1.3.0&sourceBranch=refs%2Fheads%2Fmaster&targetRepoId=917
[1.1.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_network_interface/browse?at=refs%2Ftags%2F1.0.0
[1.1.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_network_interface/browse?at=refs%2Ftags%2F1.0.1
[1.2.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_network_interface/browse?at=refs%2Ftags%2F1.2.0
[1.3.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_network_interface/browse?at=refs%2Ftags%2F1.3.0
