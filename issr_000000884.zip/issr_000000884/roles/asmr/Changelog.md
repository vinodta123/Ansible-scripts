# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased
* Combine server baseline roles into 1 role.
* IAM role for configuring LDAP & AD membership.
---

# Releases
> ## 1.0.0 - 2019-05-15
> ## 1.0.1
> ## 1.0.2 - 2019-05-28
> ## 1.1.0 - 2019-07-12
> ## 2.0.0 - 15/11/2019
>
> ### Added
> * [bugfix/CAP-36-update-asmr-role](https://jira.ah.nl/browse/CAP-36?filter=-1)