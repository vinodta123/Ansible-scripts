# Ansible Role: keymaster

This Ansible Role retrieves secrets from Azure Key Vaults and places them on the managed node. It's meant to be run from an Ansible Control Node. A private key file will be put in a mode 0600.

# Requirements

Azure Latest Modules.

# Role Variables

## Creating one or more Resource Group(s)
This role takes the following variables for when creating resource groups:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
>  * `keymaster_private_key_state`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `present`, `absent`
>    * Default Value: `present`
>    * Description: This value determines the state of the private key file. When state is 'present', the private key file will be created if not present yet. If absent, it will be removed.
>
>  * `keymaster_vmadmin_private_key`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `"{{ lookup('azure_keyvault_secret', 'vmadmin-private-key', vault_url=keymaster_azure_key_vault_url) }}"`
>    * Description: This value contains the private key contents retrieved from a file. The default value retrieves it from Azure Key Vault.
>
>  * `keymaster_private_key_path`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value:
>    * Description: This value defines the path in which the private key has to be put.
>
>  * `keymaster_azure_key_vault_url`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `'https://weeu-s01-prd-kv-gen-01.vault.azure.net/`
>    * Description: This value the Azure Key Vault url. This value is used in the defaults variable file.
>

# Examples
An example of above variable `virtual_subnets` to create multiple resource groups in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will import a private key file from Azure Key Vault.
```yaml
- name: 'Importing Secrets'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  tasks:

    - name: 'Importing Keymaster Role'
      include_role:
        name: 'keymaster'
```

## Example 1 - Playbook
This self-containing playbook is being executed from a Ansible Control Node, and will remove a private key file from local host.
```yaml
- name: 'Destroying Secrets'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  tasks:

    - name: 'Importing Keymaster Role'
      include_role:
        name: 'keymaster'
      vars:
        keymaster_private_key_state: 'absent'
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_modules).

# Author Information

Team: AH IT Cloud Foundation Team
