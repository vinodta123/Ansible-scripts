# Ansible Role: ControlM Agent

- [Ansible Role: ControlM Agent](#ansible-role-controlm_agent)

# About this role
This Ansible Role configures the following items:

__Linux__:
* Install Pre-requisite packages
* Create user and groups
* Created Folder Strucutre
* Create template for silent Installation based on varibales parsed in the playbook
* Installation of Agent base version
* Register control-m agent service
* Fix Pack Installation
* Start the Agent process



> `Control-M Agent is installed to connect to Contorl-M Server to enable the execution of the shell scripts for the respective applications`

# Role Variables (Linux)

### Control-M Agent Variables (Linux)

> * `controlm_agent_linux_package`
>   * Mandatory: `true`   (Need to be specificed under playbook only in case if Control-M Agent binary is located under a unique / different path then default location)
>   * Type: String
>   * Description: Path of the control-M Package..For Azure Devops value for the variable will be package name (controlm_agent.zip).. Defualt value set is /mnt/library/software/middleware/controlm_agent.zip (Ansible Host)

> * `controlm_agent_config`
>   * Mandatory: `true`
>   * Type: Dictionary
>   * Description: Contains a list of varibales to install the control-m agent to connect to DXC & Azure Control-m Server
>
>   * 'ctmagt_user'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (ctmagt for azure  & ctmagtdxc for DXC)
>     * Description: Name of the service account that will own the installation. for connecting to azure control-m it will be ctmagt and for connecting to DXc it will be ctmagtdxc
>
>   * 'ctmagt_userdesc'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: String
>     * Description: Control-M Agent Azure User for Azure / Control-M Agent Dxc  User
>
>   * 'ctmagt_homedir'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: String
>     * Description: HOME DIR for the service Account (/opt/ctmagt for Azure , /opt/ctmagtdxc for DXC)
>
>   * 'ctmagt_port'
>     * Mandatory: `true`
>     * Type: numeric
>     * Accepted Values: numeric (7047 for connection to Azure  & 7046 for DXC Control-M)
>     * Description: Agent Listening Port
>
>   * 'controlm_server'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (ctrlm03/t/a/p.ah.nl for Azure / ahlp1042/ahla1036/ahlt1029.ah.nl for DXC)
>     * Description: Control-m Server the agent will connnect to.
>
>   * 'ctmagt_service'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (ctmagt for Azure / ctmagtdxc for DXC)
>     * Description: Service file for restaring the Agent Services on Vm reboot
>
>   * 'ctmagt_install_path'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (/opt/ctmagt for Azure / /opt/ctmagtdxc for DXC)
>     * Description: Install directory for the Agent
>
>   * 'ctmagt_install_template'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (control-M_Agent_install for Azure / /control-M_Agent_install_dxc for DXC)
>     * Description: template file for silent installation of the Agent
>
>   * 'ctmagt_logical_volume'
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (appl_ctrlm_agent for Azure & appl_ctrlm_agent_dxc for DXC)
>     * Description: Creating Logical Volume


requirements.yml
----------------
Add the controlm_agent Repository to your requirements.yml
```yml
- src: 'git+ssh://git@bitbucket-lan.ah.nl:7999/aifr/controlm_agent.git'
  name: controlm_agent
  version: 1.2.0

servers.yml
-----------
Add import role `controlm_agent` to your servers.yml under the section configuring Linux and/or Windows servers.
```yml
# In the following play we're configuring the group 'linux'.
- name: 'Configure the Linux servers'
  hosts: 'linux'
  become: 'yes'
  tasks:

    - name: 'Importing Server Baseline Configuration Role'
      include_role:
        name: 'azure_compute_baseline'
      tags:
        - 'configure_linux'

    - name: 'Importing the Control-M Agent Role'
      import_role:
        name: 'controlm_agent'


```yaml

---

## Variable to be defined dunder playbook depending on the Agent Installation for connecting to Azure & DXC control-M Server.

controlm_agent_config: []
  - ctmagt_user: 'ctmagt'
    ctmagt_userdesc: 'Control-M Agent Azure User'
    ctmagt_homedir: '/opt/ctmagt'
    ctmagt_port: '7047'
    controlm_server: 'ctrlm03t.ah.nl'
    ctmagt_service: 'ctmagt'
    ctmagt_install_path: '/opt/ctmagt'
    ctmagt_install_template: 'control-M_Agent_install'
	ctmagt_logical_volume: 'appl_ctrlm_agent'
  - ctmagt_user: 'ctmagtdxc'
    ctmagt_userdesc: 'Control-M Agent Dxc  User'
    ctmagt_homedir: '/opt/ctmagtdxc'
    ctmagt_port: '7046'
    controlm_server: 'ahlt1029.ah.nl'
    ctmagt_service: 'ctmagtdxc'
    ctmagt_install_path: '/opt/ctmagtdxc'
    ctmagt_install_template: 'control-M_Agent_install_dxc'
	ctmagt_logical_volume: 'appl_ctrlm_agent_dxc'

controlm_agent_windows	
This Ansible Role is meant to be used to install and configure the Control-M Agent for Windows.
This Ansible Role expects the latest skeleton playbook structure to be used, as well, the Windows OS-based VM is installed with a default datadisk holding the volume name `F:\`.
	
## Network Security Group Rule to allow an inbound connection from Control-M Server

For this Control-M Agent on Windows to work properly, the following NSG port rules must be defined at the NSG of the Windows VM, as Control-M Server will connect to the Agent .  
The following is an example snippet on how this rule should look like:

### Example NSG Port rules snippet

``` yaml
# Network Security Group
nsg_port_rules:
  - name: "Allow-ControlMProduction-To-WindowsAPPProductionSubnet-TCP"
        protocol: 'Tcp'
        source_address_prefix: ['10.232.0.208/28','10.236.0.208/28']
        destination_address_prefix: '*'
        destination_port_range: ['7047']
        access: 'Allow'
        priority: 2100
        direction: 'Inbound'
```

## Role Variables (Windows)

### Control-M Agent for Windows

This role requires the following variables for when installing the Control-M Agent for Windows on a Windows OS-based VM. Variables determines the Chocolatey Package name and its repository:

> `controlm_agent_windows_choco_name`
>  * Mandatory: `false`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: `ControlM`
>  * Description: The name of the Chocolatey Package.
>
> `controlm_agent_windows_choco_repository`
>  * Mandatory: `false`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: `/mnt/library/software/middleware/client_windows/ControlM.9.0.0.nupkg`
>  * Description: The name of the Chocolatey Package. If used via Azure Devops the value will be just package name , i.e. ControlM.9.0.0.nupkg

The next variables determines the configuration of the environment variables on the Windows OS-based machine:

> `controlm_agent_inventory_hostname`
>  * Mandatory: `true`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: `ctrlm03t.ah.nl`
>  * Description: Windows VM FQDN where the Control-M Agent installation has to be done.
>
> `controlm_agent_install_path`
>  * Mandatory: `true`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: `F:\`
>  * Description: Install path location for control-m agent on windows vm.
>
> `controlm_servername`
>  * Mandatory: `true`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: `ctrlm03t.ah.nl`
>  * Description: Control-M Server that the control-m agent will connnect to (T-ctrlm03t.ah.nl / A-ctrlm03a.ah.nl / P-ctrlm03p.ah.nl)


requirements.yml
----------------
Add the controlm_agent Repository to your requirements.yml
```yml
- src: 'git+ssh://git@bitbucket-lan.ah.nl:7999/aifr/controlm_agent_windows.git'
  name: controlm_agent_windows
  version: 1.2.0

servers.yml
-----------
Add import role `controlm_agent_windows` to your servers.yml under the section configuring Windows servers.
```yml
# In the following play we're configuring the group 'Windows'.
- name: 'Configure the Windows servers'
  hosts: 'Windows'
  become: 'yes'
  tasks:


    - name: 'Importing the controlm_agent_windows Agent Role'
      import_role:
        name: 'controlm_agent'


```yaml

---

## Variable to be defined dunder playbook depending on the Agent Installation for connecting to Control-M Server / Installation path & Windows VM FQDN.

controlm_agent_inventory_hostname: 'ctrlm03t.ah.nl'
controlm_agent_install_path: 'F:\'
controlm_servername: 'ctrlm03t.ah.nl'
controlm_agent_windows_choco_repository (To be defined under playbook while using Azure DevOps Pipeline): 'ControlM.9.0.0.nupkg'


# Author Information

- Name: Nelesh Goel
- Email: nelesh.goel.nelesh.goel@ah.nl / nelesh.goel@dxc.com