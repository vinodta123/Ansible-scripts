# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


# Releases
> ## 1.0.0 
> ## 1.1.0 - 2019-06-11
>
> ### Added
> * [feature/CAP-39-update-control-m-agent-role](https://jira.ah.nl/browse/CAP-39?filter=-1) - Updated Role to Install Agent for connecting to Azure Control-M Server / DXC Control-M Server or both.
