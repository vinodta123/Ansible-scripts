# Ansible Role: iam

- [Ansible Role: iam](#ansible-role-iam)
- [About this role](#about-this-role)
  - [Default Role Behaviour](#default-role-behaviour)
    - [When being applied to a Linux Managed Node](#when-being-applied-to-a-linux-managed-node)
    - [When being applied to a Windows Managed Node](#when-being-applied-to-a-windows-managed-node)
- [Requirements](#requirements)
- [Role Variables](#role-variables)
  - [Generic Variables](#generic-variables)
  - [Local Groups - Windows & Linux](#local-groups---windows--linux)
    - [Linux](#linux)
    - [Windows](#windows)
  - [Local Accounts - Windows & Linux](#local-accounts---windows--linux)
    - [Linux](#linux-1)
    - [Windows](#windows-1)
  - [Linux LDAPS Authentication Configuration](#linux-ldaps-authentication-configuration)
  - [Windows Domain Membership](#windows-domain-membership)
  - [Linux Sudoers Configuration](#linux-sudoers-configuration)
- [Examples](#examples)
  - [Example 1 - Linux Local Group](#example-1---linux-local-group)
  - [Example 2 - Windows Local Group](#example-2---windows-local-group)
  - [Example 3 - Linux Local User](#example-3---linux-local-user)
  - [Example 4 - Windows Local User](#example-4---windows-local-user)
  - [Example 5 - Linux Sudoer Access](#example-5---linux-sudoer-access)
- [Dependencies](#dependencies)
- [Author Information](#author-information)

# About this role
This Ansible Role configures the following items:

__Windows__:
* Local Groups
* Local Accounts
* Local Account Password / Upload to Azure Key Vault
* Domain Membership
* Local Group Membership

__Linux__:
* Local Groups
* Local Accounts
* Local Account Password / Upload to Azure Key Vault
* Domain Membership
* Local Group Membership
* LDAPS
* Sudoers Configuration

## Default Role Behaviour

If the role is applied but not modified with any variables, then the following will be configured:

### When being applied to a Linux Managed Node
* The Managed Node will be configured so that it can authenticate with LDAPS against Active Directory.
* The next two default groups will be able to sudo ( a sudoers configuration file is created for each group ):
  * DSP_ADM_MLT_LinuxLocalAdmin
  * DSP_ADM_MLT_CloudOperations

### When being applied to a Windows Managed Node
* The Managed Node will be configured so that it will be joined to the emea.royalahold.net Active Directory.
* The next two default groups will be able to administer the Managed Node:
  * DSP_ADM_MLT_WindowsLocalAdmin
  * DSP_ADM_MLT_CloudOperations

# Requirements

The Ansible Control Node needs to be MSI enabled and needs to have the correct access to the Azure Key Vault in which the secrets are located for joining Active Directory.

# Role Variables

## Generic Variables

> `subscription_id`
>  * Mandatory: `true`
>  * Type: `String`
>  * Accepted Values: free form
>  * Default Value: none
>  * Description: This value determines the subscription ID in which the targeted Azure Key Vault is located.

## Local Groups - Windows & Linux

### Linux
This role takes the following variables for when creating Local Groups on Linux:
> `iam_local_linux_custom_groups`
> - Mandatory: false
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for each group that needs to be created.
>
>  * `iam_local_linux_group_name`
>    * Mandatory: `true`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value determines the group name.
>
>  * `iam_local_linux_group_state`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable is determining the state of the local group. When set to `absent`, the local group will be deleted.
>
>  * `iam_local_linux_group_local`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable is needed to create a group locally when LDAP has been configured on the Managed Node.
>
>  * `iam_local_linux_group_system`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `false`
>    * Description: This variable determines if the group is a system group.
>
>  * `iam_local_linux_group_members`
>    * Mandatory: `false`
>    * Type: `Dictionary`
>    * Accepted Values: `list`
>    * Default Value: none
>    * Description: This variable contains a list of members to add to the local group.

### Windows
This role takes the following variables for when creating Local Groups on Windows:

>`iam_local_windows_custom_groups`
> * Mandatory: false
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for each group that needs to be created.
>
>  * `iam_local_windows_group_name`
>    * Mandatory: `true`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value determines the group name.
>
>  * `iam_local_windows_group_state`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable is determining the state of the local group. When set to `absent`, the local group will be deleted.
>
>  * `iam_local_windows_group_members`
>    * Mandatory: `false`
>    * Type: `Dictionary`
>    * Accepted Values: `list`
>    * Default Value: none
>    * Description: This variable contains a list of members to add to the local group.

## Local Accounts - Windows & Linux

### Linux
This role takes the following variables for when creating Local Accounts on Linux:

> `iam_local_linux_users`
> - Mandatory: false
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for each user that needs to be created.
>
>  * `iam_local_linux_user_name`
>    * Mandatory: `true`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value determines the user name.
>
>  * `iam_local_linux_user_state`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable is determining the state of the local user. When set to `absent`, the local user will be deleted.
>
>  * `iam_local_linux_user_description`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `Created with Ansible.`
>    * Description: This value determines the description/comment for the local user.
>
>  * `iam_local_linux_user_local`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable is needed to create a user locally when LDAP has been configured on the Managed Node.
>
>  * `iam_local_linux_user_system`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `false`
>    * Description: This variable determines if the user is a system user.
>
>  * `iam_local_linux_user_shell`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the shell to use for the local user.
>
>  * `iam_local_linux_user_generate_ssh_key`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `false`
>    * Description: This variable determines if the local user is being assigned a SSH key.
>
>  * `iam_local_linux_user_password`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the password of the local user. When this variable is defined, and also the variable `iam_local_linux_user_azure_key_vault_name`, then the password will be uploaded to Azure Key Vault. The secret name in Azure Key Vault will be equal to the username of the local user. Underscores will be converted to dashes, as Azure Key Vault only accepts dashes, numbers and letters for a secret name.
>
>  * `local_linux_user_update_password`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `false`
>    * Description: This variable determines if the password of a local user needs to be set/updated. If this boolean is beeing set, and no Azure Key Vault Name variable is being given, the password will be outputted to the screen.
>>
>  * `iam_local_linux_user_azure_key_vault_name`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable contains the Azure Key Vault URI. If this variable is being set, and update password is also being set, the password will be uploaded to Azure Key Vault. If update password is not being set, then the password will be retrieved from Azure Key Vault.

### Windows
This role takes the following variables for when creating Local Accounts on Windows:

> `iam_local_windows_users`
> - Mandatory: false
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for each user that needs to be created.
>
>  * `iam_local_windows_user_name`
>    * Mandatory: `true`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value determines the user name.
>
>  * `iam_local_windows_user_state`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable is determining the state of the local user. When set to `absent`, the local user will be deleted.
>
>  * `iam_local_windows_user_description`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `Created with Ansible.`
>    * Description: This value determines the description/comment for the local user.
>
>  * `iam_local_windows_user_password`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the password of the local user. When this variable is defined, and also the variable `iam_local_windows_user_azure_key_vault_name`, then the password will be uploaded to Azure Key Vault. The secret name in Azure Key Vault will be equal to the username of the local user. Underscores will be converted to dashes, as Azure Key Vault only accepts dashes, numbers and letters for a secret name.
>
>  * `iam_local_windows_user_password_never_expires`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable determines if the password for the local user will expire.
>
>  * `iam_local_windows_user_cannot_change_password`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable determines if the local user can change the password.
>
>  * `local_windows_user_update_password`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `false`
>    * Description: This variable determines if the password of a local user needs to be set/updated. If this boolean is beeing set, and no Azure Key Vault Name variable is being given, the password will be outputted to the screen.
>
>  * `iam_local_windows_user_azure_key_vault_name`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable contains the Azure Key Vault URI. If this variable is being set, and update password is also being set, the password will be uploaded to Azure Key Vault. If update password is not being set, then the password will be retrieved from Azure Key Vault.

## Linux LDAPS Authentication Configuration
This section describes the variables needed to configure LDAPS on a Linux Managed Node.
>  * `iam_ldaps_authentication`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable determines if the Linux Managed Node needs to be configured so that it can use Active Directory as an identity source for authenticating users/group. If (a) Active Directory group(s) need to be used give logon permission(s) to the Managed Node, then also update the variable `iam_sssd_ldap_custom_access_filter` to configure the LDAPS Access Filter.
>
>  * `iam_sssd_ldap_custom_access_filter`
>    * Mandatory: `false`
>    * Type: `Dictionary`
>    * Accepted Values: `List`
>    * Default Value: none
>    * Description: This dictionary variable contains list items for each group that needs to be allowed logon access to the system. The list item needs to be in this format (replace the groupname and/or OU path):
>       * `'memberOf=cn=GSP_ADM_TCS_LinuxLocalAdmin,ou=TCS,ou=Groups,dc=Emea,dc=Royalahold,dc=net'`

## Windows Domain Membership

>  * `iam_join_domain`
>    * Mandatory: `false`
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable determines if the Windows Managed Node needs to be joined to the emea.royalahold.net Active Directory. Based on the Ansible Inventory the server will be joined to a particular Organizational Unit. Check the defaults/main.yml for the OU paths.
>
>  * `computer_description`
>    * Mandatory: `true`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable configures the computer description in Active Directory. When the azure_compute_baseline role is being used in combination with this role, then also the local computer description will be set to the same value.

## Linux Sudoers Configuration
This role takes the following variables for when creating sudoer files on Linux Managed node:

> `iam_sudoers_custom`
> - Mandatory: `false`
> - Type: `Dictionary`
> - Description: This dictionary variable contains list items for each group that needs sudo permissions on the Managed Node.
>
>  * `iam_sudoers_group_name`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This value determines the group name that needs sudo access.
>
>  * `iam_sudoers_group_state`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: `present`,`absent`
>    * Default Value: `present`
>    * Description: This value determines state of the sudoers config.
>
>  * `iam_sudoers_group_access`
>    * Mandatory: `false`
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `/bin/ls`
>    * Description: This variable determines the sudo access or commands that the group is allowed to run.

# Examples

## Example 1 - Linux Local Group
An example of above variable `iam_local_linux_custom_groups` to create multiple local groups on a Linux Managed Node:
```yaml
iam_local_linux_custom_groups:
  - iam_local_linux_group_name: 'oracle'
    iam_local_linux_group_members:
      - 'oracleadmin'
  - iam_local_linux_group_name: 'tomcat'
    iam_local_linux_group_system: true
    iam_local_linux_group_members:
      - 'svc_tomcat'
```

## Example 2 - Windows Local Group
An example of above variable `iam_local_windows_custom_groups` to create multiple local groups on a Linux Managed Node:
```yaml
iam_local_windows_custom_groups:
  - iam_local_windows_group_name: 'sqladmins'
    iam_local_windows_group_members:
      - 'sqladmin'
  - iam_local_windows_group_name: 'iis'
    iam_local_windows_group_members:
      - 'svc_iis'
```

## Example 3 - Linux Local User
An example of above variable `iam_local_linux_custom_users` to create multiple local users with a password retrieved from Azure Key Vault:
```yaml
iam_local_linux_default_users:
  # This will create/update the user 'oracle'. The password will be auto generated and uploaded to the specified Azure Key Vault.
  - iam_local_linux_user_name: 'oracle'
    iam_local_linux_user_update_password: true
    iam_local_linux_user_password: "{{ (lookup('azure_keyvault_secret', 'oracle/', vault_url='https://weeu-s01-prd-kv-simp-01.vault.azure.net/')) }}"
    iam_local_linux_user_azure_key_vault_name: 'WeEu-S03-Dev-Kv-Simp-01'
  # This will create/update the user 'tomcat'. The password will be retrieved from Azure Key Vault and set on the user. This assumes the secret already exists in Azure Key Vault.
  - iam_local_linux_user_name: 'ansible'
    iam_local_linux_user_password: "{{ (lookup('azure_keyvault_secret', 'oracle/', vault_url='https://weeu-s01-prd-kv-simp-01.vault.azure.net/')) }}"
    iam_local_linux_user_update_password: true
```

## Example 4 - Windows Local User
```yaml
iam_local_windows_default_users:
  # This will create/update the user 'sqladmin'. The password will be auto generated and uploaded to the specified Azure Key Vault.
  - iam_local_windows_user_name: 'sqladmin'
    iam_local_windows_user_update_password: true
    iam_local_windows_user_password: "{{ (lookup('azure_keyvault_secret', 'sqladmin/', vault_url='https://weeu-s01-prd-kv-simp-01.vault.azure.net/')) }}"
    iam_local_windows_user_azure_key_vault_name: 'WeEu-S03-Dev-Kv-Simp-01'
  # This will create/update the user 'tomcat'. The password will be retrieved from Azure Key Vault and set on the user. This assumes the secret already exists in Azure Key Vault.
  - iam_local_windows_user_name: 'svc_sqlagent'
    iam_local_windows_user_password: "{{ (lookup('azure_keyvault_secret', 'svc_sqlagent/', vault_url='https://weeu-s01-prd-kv-simp-01.vault.azure.net/')) }}"
    iam_local_windows_user_update_password: true
```

## Example 5 - Linux Sudoer Access
An example of variable `iam_sudoers_custom` to create sudoer file allowing sudo access to local group:
```yaml
iam_sudoers_custom:
  # This will create/update the sudoer file 'DST_APP_MLT_StoresSupport'. Any user who belongs to DST_APP_MLT_StoresSupport group will be able to run less and cat command as any user inlcuding root.
  - iam_sudoers_group_name: 'DST_APP_MLT_StoresSupport'
    iam_sudoers_group_access: '/bin/less, /bin/cat'
  # This will create/update the sudoer file 'DST_APP_MLT_AHStoreSupport'. Any user who belongs to DST_APP_MLT_AHStoreSupport group will be able to run ls command as any user inlcuding root.
  - iam_sudoers_group_name: 'DST_APP_MLT_AHStoreSupport'
```

## Example 6 - Windows Computer Description
An example of variable `iam_computer_description` to be readable in Active Directory:
```yaml
## Computer Description of the VMs
iam_computer_descriptions:
  # weeus03dwsimp01 - westeurope
  - iam_virtual_machine_name: "weeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}{{ os_type | first | lower }}{{ application_shortname | lower }}01"
    iam_computer_description: "Application Server for the Simpsons"
  # noeus03dwsimp01 - northeurope
  - iam_virtual_machine_name: "noeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}{{ os_type | first | lower }}{{ application_shortname | lower }}01"
    iam_computer_description: "Webserver for the Simpsons Application"
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_modules).

# Author Information

Team: AH IT Cloud Foundation Team
