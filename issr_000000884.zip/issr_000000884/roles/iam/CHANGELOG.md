# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
* Nothing planned
---

# Releases

> ## [1.2.1] - 2019-07-29
>
> ### Changed
> * [TCSCLDVPS-1354](https://jira.ah.nl/browse/TCSCLDVPS-1354) - Changed Windows PowerShell bridge server from stepstone to hybrid worker
> * [TCSCLDVPS-1452](https://jira.ah.nl/browse/TCSCLDVPS-1452) - Fixed bug after TCSCLDVPS-490 which caused duplicated Computer Objects (CNF records) for Windows Domain Joined VMs.
> * [TCSCLDVPS-1453](https://jira.ah.nl/browse/TCSCLDVPS-1453) - Made the Computer Description for Windows Domain Joined VMs mandatory. 

> ## [1.2.0] - 2019-05-17
>
> ### Added
> * [TCSCLDVPS-490](https://jira.ah.nl/browse/TCSCLDVPS-490) - Provide Computer Description
>
> ### Fixed
> * [TCSCLDVPS-1109](https://jira.ah.nl/browse/TCSCLDVPS-1109) - Removal of custom sudoers configuration
>
> ## [1.1.1] - 2019-05-02
>
> ### Changed
> * [CAP-33](https://jira.ah.nl/browse/CAP-33)
>   * Fixed local linux account expiry issue. Password now set 'never to expire'
>
> ## [1.1.0] - 2019-04-07
>
> ### Changed
> * [CAP-32](https://jira.ah.nl/browse/CAP-32)
>   * Extended sudoer functionality, allowing custom commands to be inlcuded in sudoer file.
>
> ## [1.0.1] - 2019-03-20
>
> ### Changed
> * [TCSCLDVPS-956](https://jira.ah.nl/browse/TCSCLDVPS-956)
>   * Corrected wrong conditional on Local Group task
>   * Changed default behaviour of adding domain groups in local Administrators group
>   * Added 'destroy' functionality for a local group
>
> ## [1.0.0] - 2019-03-18
>
> ### Added
> * [TCSCLDVPS-794](https://jira.ah.nl/browse/TCSCLDVPS-794) - Initial Release

[Unreleased]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/iam/compare/diff?targetBranch=refs%2Ftags%2Fv1.2.0&sourceBranch=refs%2Fheads%2Fmaster&targetRepoId=976
[1.0.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/iam/browse?at=refs%2Ftags%2Fv1.0.0
[1.0.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/iam/browse?at=refs%2Ftags%2Fv1.0.1
[1.1.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/iam/browse?at=refs%2Ftags%2Fv1.1.0
[1.1.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/iam/browse?at=refs%2Ftags%2Fv1.1.1
[1.2.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/iam/browse?at=refs%2Ftags%2Fv1.2.0
