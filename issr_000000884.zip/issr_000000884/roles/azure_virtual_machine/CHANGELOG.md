# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
Nothing Planned.
---

# Releases

> ## [1.5.1] - 2019-09-25
>
> ### Added
> * [TCSCLDVPS-1628] (https://jira.ah.nl/browse/TCSCLDVPS-1628) - Fixed problem with Rapid7 VM extension installation
>
> ## [1.5.0] - 2019-08-27
>
> ### Added
> * [TCSCLDVPS-1317] (https://jira.ah.nl/browse/TCSCLDVPS-1317) - Added additional business units in assertion
> * [TCSCLDVPS-1319] (https://jira.ah.nl/browse/TCSCLDVPS-1319) - Added AE application ids in assertion
>
> ## [1.4.0] - 2019-06-14
>
> ### Added
> * [TCSCLDVPS-1162](https://jira.ah.nl/browse/TCSCLDVPS-1162) - Added Commvault Backup Tag
>
> ### Changed
> * [TCSCLDVPS-1162](https://jira.ah.nl/browse/TCSCLDVPS-1162) - Changed how the Component Tag gets added to the Azure Tags Dictionary
>
> ## [1.3.0] - 2019-05-17
>
> ### Added
> * [TCSCLDVPS-796](https://jira.ah.nl/browse/TCSCLDVPS-796) - Added Rapid7 Extension
>
> ## [1.2.0] - 2019-05-06
>
> ### Added
> * [TCSCLDVPS-640](https://jira.ah.nl/browse/TCSCLDVPS-640) - Enabled Hybrid Use Benefit functionality
>
> ## [1.1.0] - 2019-04-22
>
> ### Added
> * [TCSCLDVPS-1039](https://jira.ah.nl/browse/TCSCLDVPS-1039) - Added Availability Zone functionality
>
> ### Fixed
> * [TCSCLDVPS-973](https://jira.ah.nl/browse/TCSCLDVPS-973) - Fixed GALL&GALL Assertion to Gall & Gall
>
> ### Changed
> * [TCSCLDVPS-987](https://jira.ah.nl/browse/TCSCLDVPS-987) - Made Azure Backup Optional
>
> ## [1.0.1] - 2019-04-04
>
> ### Added
> * [TCSCLDVPS-1010](https://jira.ah.nl/browse/TCSCLDVPS-1010) - Added support for Log Analytics workspace in S06 Azure subscription
>
> ## [1.0.0] - 2019-03-01
>
> ### Added
> * [TCSCLDVPS-637](https://jira.ah.nl/browse/TCSCLDVPS-637)   - Initial Release

[Unreleased]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/compare/diff?targetBranch=refs%2Ftags%2F1.5.0&sourceBranch=refs%2Fheads%2Fmaster&targetRepoId=653
[1.0.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.0.0
[1.0.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.0.1
[1.1.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.1.0
[1.2.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.2.0
[1.3.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.3.0
[1.4.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.4.0
[1.5.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.5.0
[1.5.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_virtual_machine/browse?at=refs%2Ftags%2F1.5.1
