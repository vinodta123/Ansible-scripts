# Ansible Role: azure_virtual_machine

This Ansible Role creates an Azure Virtual Machine. Please be aware that this role only can be used to deploy at one subscription at a time. If it is needed to deploy to another subscription, then this has to be arranged with the means of targeting your Azure authentication. More information [here](https://docs.ansible.com/ansible/latest/scenario_guides/guide_azure.html). At AH IT we are using a Managed Identity for Azure Resources to authenticate and target a Azure subscription.

# Requirements

This role is meant to be used to provision one or more Virtual Machine(s) in one of the Azure subscriptions of Albert Heijn.

# Role Variables

## Creating one or more Virtual Machine(s)
This role takes the following variables for when creating resource groups:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
> `azure_tags`
> * Mandatory: Optional, but will be set to `None` automatically if not defined.
> * Type: Dictionary
> * Mandatory Keys & Values:
>    * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>  * Description: This dictionary variable sets mandatory Azure Tags on the Virtual Machine. If they are not set, then the role will create the `azure_tags` variable automatically. It will be set based on the mandatory keys and values as specified above. If these are not set, then role will fail to run. For more information on the mandatory tags and allowed values click [here](https://confluence.ah.nl/display/ACF/Tags)
>
If the `azure_tags` is not set, then the following variables need to be set, otherwise Azure Policy will block the provisioning of resources:
>   * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)

When you want to specify the component tag per host group then this variable should be added in the variable file for the virtual machine host group. It will be added to the existing tags of the Virtual Machine(s):
>  * __component_name__: [check here](https://confluence.ah.nl/display/ACF/Tags)

For an example on how to do this in a playbook, check this file: [link](https://bitbucket.ah.nl/projects/CAP/repos/skeleton/browse/inventories/s03_development/group_vars/windows_webservers/azure_virtual_machine.yml)

The next variables determine the virtual machine(s):
>`virtual_machines`
> - Type: Dictionary
> - Description: This dictionary variable contains a list item for each Virtual Machine.
>
>  * `virtual_machine_state`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: present,absent
>    * Default Value: present
>    * Description: This value determines the state of the Virtual Machine. When state is 'present', the Virtual Machine will be created if not present yet. If absent, it will be removed.
>
>  * `virtual_machine_name`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `None`
>    * Description: This variable determines the name of the Virtual Machine to create. Please check the naming convention here for allowed values: [AH IT Naming Convention](https://confluence.ah.nl/display/ACF/Naming+Convention#NamingConvention-AzureVirtualMachinesNamingConvention)
>
>  * `virtual_machine_auto_shutdown_schedule`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `None`
>    * Description: This variable determines the name of the Virtual Machine to create. Please check the Auto Shutdown Schedule Values here for allowed values: [AH IT Scheduled Virtual Machine Shutdown](https://confluence.ah.nl/pages/viewpage.action?pageId=31240795#ScheduledVirtualMachineShutdown/Startup-Howtoconfiguretheshutdownschedules)
>
>  * `virtual_machine_component_name`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `None`
>    * Description: This variable determines the component name of the Virtual Machine. Please check the Component Values here for allowed values: [AH IT Tags](https://confluence.ah.nl/display/ACF/Tags)
>
>  * `virtual_machine_commvault_backup`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `None`
>    * Description: This variable determines the Commvault Backup Schedule for the Virtual Machine. Please check the Commvault Backup Schedule Values here for allowed values: [Commvault - Virtual Machine Backup](https://confluence.ah.nl/display/COO/Virtual+Machine+Backup)
>
>  * `virtual_machine_application_resource_group_name`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: present,absent
>    * Default Value: `none`
>    * Description: This value targets the resource group in which to create the Virtual Machine.
>
>  * `virtual_machine_size`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: Please check this [link](https://docs.microsoft.com/en-us/azure/virtual-machines/windows/sizes)
>    * Default Value: `Standard_DS3_v2`
>    * Description: This value specifies the Virtual Machine size.
>
>  * `virtual_machine_os_type`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: `Linux`, `Windows`
>    * Default Value: `none`
>    * Description: This value specifies the Operating System. Based on this choice also the first local administrator account will be configured with either a password(Windows) or ssh key(Linux). Also extensions will be added to the Virtual Machine based on this choice, e.g. WinRM for Windows, Log Analytics Agent for Linux, etc.
>
>  * `virtual_machine_managed_disk_type`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `Premium_LRS`, `Standard_LRS`
>    * Default Value: `Premium_LRS`
>    * Description: This variable determines the managed disk type.
>
>  * `virtual_machine_os_disk_size_gb`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `Premium_LRS`, `Standard_LRS`
>    * Default Value: `127`
>    * Description: This variable determines the size of the operating system disk. Size is specified in GB. On the Azure platform the size is showed in GiB.
>
>  * `virtual_machine_admin_username`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `vmadmin`
>    * Default Value: `vmadmin`
>    * Description: The value for the first local administrator on a Virtual Machine.
>
>  * `virtual_machine_admin_public_key`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `vmadmin`
>    * Default Value: The default value will be retrieved from Azure Key Vault.
>    * Description: The value for the first local administrator on a Virtual Machine. This particular value is valid only for a Linux Virtual Machine, but only either a password OR public key can be configured at the same time can be configured on a Linux server.
>
>  * `virtual_machine_admin_password`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `vmadmin`
>    * Default Value: The default value will be retrieved from Azure Key Vault.
>    * Description: The value for the first local administrator on a Virtual Machine. This particular value is valid for a Linux and Windows Virtual Machine, but only either a password OR public key can be configured at the same time can be configured on a Linux server.
>
>  * `virtual_machine_image_offer`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Platform Image offer.
>
>  * `virtual_machine_image_publisher`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Platform Image Publisher.
>
>  * `virtual_machine_image_sku`
>    * Mandatory: `true`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Platform Image Stock Keeping Unit.
>
>  * `virtual_machine_image_version`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `Latest`
>    * Description: This value targets the Azure Platform Image Version.
>
>  * `virtual_machine_image_name`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Managed Image Name.
>
>  * `virtual_machine_managed_image_resource_group`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the resource group in which the managed image is located.
>
>  * `virtual_machine_plan`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Marketplace Virtual Machine Plan.
>
>  * `virtual_machine_plan_publisher`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Marketplace Virtual Machine Plan Publisher.
>
>  * `virtual_machine_plan_product`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Marketplace Virtual Machine Plan Product.
>
>  * `virtual_machine_plan_promotion_code`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This value targets the Azure Marketplace Virtual Machine Plan Promotion Code.
>
>  * `virtual_machine_network_interfaces`
>    * Mandatory: `true`
>    * Type: Dictionary
>    * Description: This variable contains a list of network interfaces that has to be connected to the Virtual Machine.
>
>  * `virtual_machine_availability_set_name`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This variable contains the availability set name that the Virtual Machine has to be attached to.
>
>  * `virtual_machine_zones`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `''`,`1`,`2`,`3`
>    * Default Value: `none`
>    * Description: This variable contains the availability zone number to which the Virtual Machine should be deployed to.
>
>  * `virtual_machine_license_type`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: `none`,`Windows_Server`, `Windows_Client`
>    * Default Value: `Windows_Server`
>    * Description: This variable contains the license type for the Virtual Machine, and will configure Hybrid Use Benefit on a Windows Virtual Machine.
>
>  * `virtual_machine_boot_diagnostics_primary_blob_endpoint`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This variable contains the uri for the primary blob to store boot diagnostics.
>
>  * `virtual_machine_recovery_services_vault_resource_group`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This variable contains the name of the resource group in which the services vault is located.
>
>  * `virtual_machine_recovery_service_vault_name`
>    * Mandatory: `false`
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: `none`
>    * Description: This variable contains the name of the services vault to be used. Has to be used in combination with the `virtual_machine_recovery_services_vault_resource_group` variable.

# Examples
An example of above variable `virtual_machines` to create multiple Virtual Machines in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create two Virtual Machines. This example assumes that the availability sets and network interfaces are already created.

```yaml
- name: 'Create Virtual Machines'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: `false`
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  vars:
    business_unit_name: 'Albert Heijn'
    application_name: 'Simpsons App'
    application_id: 'AP000000000'
    environment_name: 'Development'
    live_status: 'No'
    playbook_version: '0.1.0'
    virtual_machines:
    # weeus03dlsimp01 - westeurope
      - virtual_machine_name: "weeus03devlsimp01"
        virtual_machine_application_resource_group_name: "WeEu-S03-Dev-Rsg-Simp-01"
        virtual_machine_os_type: 'Linux'
        virtual_machine_auto_shutdown_schedule: 'Simulate'
        virtual_machine_managed_image_name: 'rhel-7.5-cis-v1.0.0'
        virtual_machine_managed_image_resource_group: "WeEu-S03-Dev-Rsg-Pckr-01"
        virtual_machine_availability_set_name: "WeEu-S03-Dev-As-Simp-01"
        virtual_machine_boot_diagnostics_primary_blob_endpoint: "https://weeus03devsasimp01.blob.core.windows.net/"
        virtual_machine_recovery_services_vault_resource_group: "WeEu-S03-Dev-Rsg-Rsvt-01"
        virtual_machine_recovery_service_vault_name: "WeEu-S03-Dev-Rsvt-01"
    # noeus03dlsimp01 - northeurope
      - virtual_machine_name: "noeus03devlsimp01"
        virtual_machine_application_resource_group_name: "NoEu-S03-Dev-Rsg-Simp-01"
        virtual_machine_os_type: 'Linux'
        virtual_machine_auto_shutdown_schedule: 'Simulate'
        virtual_machine_managed_image_name: 'rhel-7.5-cis-v1.0.0'
        virtual_machine_managed_image_resource_group: "NoEu-S03-Dev-Rsg-Pckr-01"
        virtual_machine_boot_diagnostics_primary_blob_endpoint: "https://noeus03devsasimp01.blob.core.windows.net/"
        virtual_machine_availability_set_name: "NoEu-S03-Dev-As-Simp-01"
        virtual_machine_recovery_services_vault_resource_group: "NoEu-S03-Dev-Rsg-Rsvt-01"
        virtual_machine_recovery_service_vault_name: "NoEu-S03-Dev-Rsvt-01"
  tasks:
    - name: 'Import Azure Virtual Machine Role'
      include_role:
        name: 'azure_virtual_machine'
```
## Example 2 - Code Snippet
This will create 2 resource groups including Azure tags that are set on a generic level. The resource groups are getting created in two different regions.

General values that will be used to construct the Azure Tags:
```yaml
azure_tags:
  business_unit_name: 'Albert Heijn'
  application_name: 'Simpsons App'
  application_id: 'AP000000000'
  environment_name: 'Development'
  live_status: 'No'
  playbook_version: '0.1.0'
```
```yaml
virtual_machines:
# weeus03dlsimp01 - westeurope
  - virtual_machine_name: "weeus03devlsimp01"
    virtual_machine_application_resource_group_name: "WeEu-S03-Dev-Rsg-Simp-01"
    virtual_machine_os_type: 'Linux'
    virtual_machine_auto_shutdown_schedule: 'Simulate'
    virtual_machine_managed_image_name: 'rhel-7.5-cis-v1.0.0'
    virtual_machine_managed_image_resource_group: "WeEu-S03-Dev-Rsg-Pckr-01"
    virtual_machine_availability_set_name: "WeEu-S03-Dev-As-Simp-01"
    virtual_machine_boot_diagnostics_primary_blob_endpoint: "https:/weeus03devsasimp01.blob.core.windows.net/"
    virtual_machine_recovery_services_vault_resource_group: "WeEu-S03-Dev-Rsg-Rsvt-01"
    virtual_machine_recovery_service_vault_name: "WeEu-S03-Dev-Rsvt-01"
# noeus03dlsimp01 - northeurope
  - virtual_machine_name: "noeus03devlsimp01"
    virtual_machine_application_resource_group_name: "NoEu-S03-Dev-Rsg-Simp-01"
    virtual_machine_os_type: 'Linux'
    virtual_machine_auto_shutdown_schedule: 'Simulate'
    virtual_machine_managed_image_name: 'rhel-7.5-cis-v1.0.0'
    virtual_machine_managed_image_resource_group: "NoEu-S03-Dev-Rsg-Pckr-01"
    virtual_machine_boot_diagnostics_primary_blob_endpoint: "https:/noeus03devsasimp01.blob.core.windows.net/"
    virtual_machine_availability_set_name: "NoEu-S03-Dev-As-Simp-01"
    virtual_machine_recovery_services_vault_resource_group: "NoEu-S03-Dev-Rsg-Rsvt-01"
    virtual_machine_recovery_service_vault_name: "NoEu-S03-Dev-Rsvt-01"
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Preview modules: [GitHub](https://github.com/Azure/azure_modules).

# Author Information

Team: AH IT Cloud Foundation Team
