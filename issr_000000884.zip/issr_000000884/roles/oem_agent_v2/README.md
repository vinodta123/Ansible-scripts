# Ansible Role: oem_agent_v2

- [Ansible Role: oem_agent_v2](#oem_agent_v2)
- [About this role](#about-this-role)
- [Default Role Behaviour](#default-role-behaviour)
- [When being applied to a Linux Managed Node](#when-being-applied-to-a-linux-managed-node)
- [Requirements](#requirements)
- [Role Variables](#role-variables)
- [Examples](#examples)
- [Dependencies](#dependencies)
- [Author Information](#Author-Information)

# About this role
This Ansible Role will install orcale_database_oem_agent with the new skeletton.
This role is tested on wuus01planse04 and Azure devops.

__Linux__:
* Install OEM packages.
* Configures the OEM agent.

## Default Role Behaviour
If the role is applied Oracle Enterprise Manager Agent (oem_agent) will be installed on the target host.
This needs to be done after the oracle database is installed.
You need to at least specify few variables for this please take a look a the example section.

### When being applied to a Linux Managed Node
* Oracle oem_agent packages will be installed.

# Requirements
- The Ansible Control Node needs to be MSI enabled and needs to have the correct access to the Azure Key Vault in which the secrets are located for joining Active Directory.
- This role must be executed after `iam` role which sets up the Active directory configuration (sssd config).

#Role Variables
> `oem_agent_pw`
> - Mandatory: `true`
> - Type: `List`
> - Description: This List variable contains password for the oem agent.
> - Example: oem_agent_pw: "{{ (lookup('azure_keyvault_secret', 'oem-agent-pw', vault_url=azure_key_vault_url_okrb)) }}"
>
> `oem_server_host:`
> - Mandatory: `false`
> - Type: `List`
> - Description: This List variable must be provided default is oem002.ah.nl
>

# Examples

## Example 1 - oem_agent

```yaml

- name: 'Importing the oem_agent_v2 Role'
  import_role:
    name: 'oem_agent_v2'
  tags:
   - 'oem_agent_v2'

```

## Oracle oem_agent playbook Vars:
```yaml

azure_key_vault_url_okrb: 'https://weeu-s03-dev-kv-okrb-01.vault.azure.net/'
oem_agent_pw: "{{ (lookup('azure_keyvault_secret', 'oem-agent-pw', vault_url=azure_key_vault_url_okrb)) }}"

```

# Dependencies
This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_modules).

This role can be installed after the oracle dabase role.

# Author Information
- Name: Jelle de Bruin
- Email: jelle.bruin.de@ah.nl

- Name: Jesse Mirza
- Email: jesse.mirza@ah.nl
