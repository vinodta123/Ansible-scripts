# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
### Changed
- Update based on the peer review.

# Releases
> ## 1.1.0 - 2019-07-18  (Updates has been to set the INTF Env for the Application and also configure DB ENV)
> ## 1.2.0 - 2019-10-28  (User password set to never to expire and also made compatible with Azure DevOps)

> ### Added
> * [feature/CAP-43-update-intf_base-role] (https://jira.ah.nl/browse/CAP-43)
> * [bugfix/CAP-52-update-intf-role] (https://jira.ah.nl/browse/CAP-52)

