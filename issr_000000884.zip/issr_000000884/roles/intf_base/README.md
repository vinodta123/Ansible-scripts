# Ansible Role: intf_base

- [Ansible Role: intf_base](#ansible-role-intf_base)

# About this role
This Ansible Role configures the following items:

__Linux__:
* FileSystem
* INTF binaries
* INTF Configuration
* INTF Environment setup for APP
* INTF profie setup
* DB config for INTF
* Folder Strucutre
* Symbolic Links
* Permissions


# Role Variables

### intf_base Mandatory Variables

>   * intf_installer
>   * Mandatory: `true`   (Need to be specificed under playbook only in case if intf_local.zip binary is located under a unique / different path then default location)
>   * Type: String
>   * Description: Path of the intf base package..For Azure Devops value for the variable will be package name (intf_local.zip).. Defualt value set is /mnt/library/software/middleware/intf_local.zip (Ansible Host)
>   * intf_env
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: string (3 letter env code, e.g. dev/tst/acc/prd)
>     * Description: Environmetn string value
>
>   * intf_db_sid
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: String
>     * Description: SID for the database to be defined (r.g. asepmah1 )
>


> `INTF is middleware components for Ahold Application installed on Linux and is used for Interfacing  maily between Databases and is also used for file transfer.

requirements.yml
----------------
Add the intf_base Repository to your requirements.yml
```yml
- src: 'ssh://git@bitbucket-lan.ah.nl:7999/car/intf_base.git'
  name: intf_base
  version: <optional>

servers.yml
-----------
Add import role `intf_base` to your servers.yml under the section configuring Linux and/or Windows servers.
```yml
# In the following play we're configuring the group 'linux'.
- name: 'Configure the Linux servers'
  hosts: 'linux'
  become: 'yes'
  tasks:

    - name: 'Importing Server Baseline Configuration Role'
      include_role:
        name: 'azure_compute_baseline'
      tags:
        - 'configure_linux'

    - name: 'Importing the Intf base Role'
      import_role:
        name: 'intf_base'


```yaml

## Variable to be defined under playbook (Values defined below are examples).

intf_env: 'acc'
intf_db_sid: 'asepmah1'


---

# Author Information

- Name: Nelesh Goel
- Email: nelesh.goel.nelesh.goel@ah.nl / nelesh.goel@dxc.com