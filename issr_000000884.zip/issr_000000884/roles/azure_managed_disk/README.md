# Ansible Role: azure_managed_disk

This Ansible Role creates an Azure Managed Disk. Please be aware that this role only can be used to deploy at one subscription at a time. If it is needed to deploy to another subscription, then this has to be arranged with the means of targeting your Azure authentication. More information [here](https://docs.ansible.com/ansible/latest/scenario_guides/guide_azure.html). At AH IT we are using a Managed Identity for Azure Resources to authenticate and target a Azure subscription.

# Requirements

This role is meant to be used to provision one or more Managed Disk(s) in one of the Azure subscriptions of Albert Heijn.

# Role Variables

## Creating one or more Managed Disk(s)
This role takes the following variables for when creating resource groups:

The following variables need to be set at a generic level. See the playbook example below in this document for a example.
> `azure_tags`
> * Mandatory: Optional, but will be set automatically if not defined.
> * Type: Dictionary
> * Mandatory Keys & Values:
>    * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>    * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>  * Description: This dictionary variable sets mandatory Azure Tags on the Managed Disk. If they are not set, then the role will create the `azure_tags` variable automatically. It will be set based on the mandatory keys and values as specified above. If these are not set, then role will fail to run. For more information on the mandatory tags and allowed values click [here](https://confluence.ah.nl/display/ACF/Tags)
>
If the `azure_tags` is not set, then the following variables need to be set, otherwise Azure Policy will block the provisioning of resources:
>   * __Business Unit Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application Name__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Application ID__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Environment__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Live__: [check here](https://confluence.ah.nl/display/ACF/Tags)
>   * __Playbook Version__: [check here](https://confluence.ah.nl/display/ACF/Tags)

The next variables determine the resource group:
>`managed_disks`
> - Type: Dictionary
> - Description: This dictionary variable contains a list item for each Managed Disk.
>
>  * `managed_disk_state`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `present`, `absent`
>    * Default Value: `present`
>    * Description: This value determines the state of the Managed Disk. When state is 'present', the Managed Disk will be created if not present yet. If absent, it will be removed.
>
>  * `managed_disk_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the name of the Managed Disk to create. Please check the naming convention here for allowed values: [AH IT Naming Convention](https://confluence.ah.nl/display/ACF/Naming+Convention#NamingConvention-AzureManagedDisksNamingConventionn)
>
>  * `managed_disk_resource_group_name`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines resource group in which the Managed Disk has to be created.
>
>  * `managed_disk_size_gb`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `32`, `64`, `128`, `256`, `512`, `1024`, `2048`, `4096`
>    * Default Value: `64`
>    * Description: This variable determines the disk size.
>
>  * `managed_disk_type`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `Premium_LRS`, `Standard_LRS`
>    * Default Value: `Premium_LRS`
>    * Description: This variable determines the type of the Managed Disk.
>
>  * `managed_disk_attached_to`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines to which Virtual Machine this disk is attached to. When left empty it will be created but not attached to a Virtual Machine.
>
>  * `managed_disk_zone`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: `''`,`1`,`2`,`3`
>    * Default Value: none
>    * Description: This variable determines to which Availability Zone the managed disk needs to be deployed to. This should be the same zone as the Virtual Machine.


# Examples
An example of above variable `managed_disks` to create multiple network security groups in different locations:

## Example 1 - Playbook
This self-containing playbook is being executed from a MSI enabled Ansible Control Node, and will create two resource groups.
```yaml
- name: 'Create Managed Disks'
  hosts: 'localhost'
  connection: 'local'
  gather_facts: false
  environment:
    ANSIBLE_AZURE_AUTH_SOURCE: 'msi'
    AZURE_SUBSCRIPTION_ID: '24d982bc-43e1-4e58-a537-abb3fc74d1c7'
  vars:
    business_unit_name: 'Albert Heijn'
    application_name: 'Simpsons App'
    application_id: 'AP000000000'
    environment_name: 'Development'
    live_status: 'No'
    playbook_version: '0.1.0'
    managed_disks:
      - managed_disk_name: 'WeEu-S03-Dev-As-Simp-01'
        managed_disk_resource_group_name: 'WeEu-S03-Dev-Rsg-Simp-01'
      - managed_disk_name: 'NoEu-S03-Dev-As-Simp-01'
        managed_disk_resource_group_name: 'NoEu-S03-Dev-Rsg-Simp-01'

  tasks:
    - name: 'Import Azure Managed Disk Role'
      include_role:
        name: 'azure_managed_disk'
```
## Example 2 - Code Snippet
This will create 2 resource groups including Azure tags that are set on a generic level. The resource groups are getting created in two different regions.

General values that will be used to construct the Azure Tags:
```yaml
azure_tags:
  business_unit_name: 'Albert Heijn'
  application_name: 'Simpsons App'
  application_id: 'AP000000000'
  environment_name: 'Development'
  live_status: 'No'
  playbook_version: '0.1.0'
```
```yaml
managed_disks:
  - managed_disk_name: "weeus03dlsimp01-datadisk-01"
    managed_disk_resource_group_name: "WeEu-S03-Dev-Rsg-Simp-01"
    managed_disk_attached_to: "weeus03dlsimp01"
  - managed_disk_name: "noeus03dlsimp01-datadisk-01"
    managed_disk_resource_group_name: "NoEu-S03-Dev-Rsg-Simp-01"
    managed_disk_attached_to: "noeus03dlsimp01"
```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Preview modules: [GitHub](https://github.com/Azure/azure_preview_modules).

# Author Information

Team: AH IT Cloud Foundation Team
