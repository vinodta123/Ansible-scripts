# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
> * Dynamicly get guid of windows installer for uninstallation.

---

# Releases
> ### [1.2.2](https://bitbucket.ah.nl/projects/AHITCFAR/repos/commvault_agent/browse?at=refs%2Ftags%2F1.2.2) - 2019-10-08
> ### BugFix
> * minor change in checking assertions for variable "commvault_agent_vm_exclude_disk" is defined. Thx to @Jesse Mirza
>
> ### [1.2.1](https://bitbucket.ah.nl/projects/AHITCFAR/repos/commvault_agent/browse?at=refs%2Ftags%2F1.2.1) - 2019-10-07
> ### Added
> * minor change in checking installation status of Commvault Agent. Thx to @Nelesh
>
> ### [1.2.0](https://bitbucket.ah.nl/projects/AHITCFAR/repos/commvault_agent/browse?at=refs%2Ftags%2F1.2.0) - 2019-10-04
> ### Added
> * [TCSCLDVPS-1553](https://jira.ah.nl/browse/TCSCLDVPS-1553) - Exclude Data Disks in snapshot Commvault VM Backup through Ansible Role
> * NOTE! All 'sql' variables are changed to 'mssql' for clarity. Because this role also supports 'MySql'
>
> ### [1.1.0](https://bitbucket.ah.nl/projects/AHITCFAR/repos/commvault_agent/browse?at=refs%2Ftags%2F1.1.0) - 2019-09-04
> ### Added
> * [TCSCLDVPS-1122](https://jira.ah.nl/browse/TCSCLDVPS-1122) - Ability to install and configure MySQL/MariaDB
>
> ### [1.0.0](https://bitbucket.ah.nl/projects/AHITCFAR/repos/commvault_agent/browse?at=refs%2Ftags%2F1.0.0) - 2019-04-03
> ### Added
> * [TCSCLDVPS-541](https://jira.ah.nl/browse/TCSCLDVPS-541) - Initial Release
