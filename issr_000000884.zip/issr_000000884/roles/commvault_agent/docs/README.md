Role Name - Commvault Agent
===========================

This Ansible Role installs the Commvault Agent on the local server.\
The Agent can be used for filelevel, SQL and Oracle backups.

Requirements
------------

This role should only be used when there is a need for local backups.\
For Virtual Machine backups this role is not needed.\
More information how to use Virtual Machine backup and general Commvault use see:\
__Confluence Commvault Page__: [click here](https://confluence.ah.nl/display/COO/Commvault)

In the hosts.ini your playbook you need to specify the full qualified domain name and the shortname.\
like this:\
[hostgroup]\
weeus01pwxxxx01.shd.eu.aholddelhaize.com inventory_hostname_short=weeus01pwxxxx01

Role Variables
--------------

This role takes the following variables to enroll the Commvault Agent and backup policies.
> Note that the policies and schedules now defined can be extended and can be found on the __Confluence Commvault Page__.

> * `commvault_agent_script_user_password`
>   * Mandatory: `true`
>   * Type: String
>   * Description: Password off the service account that is used for connecting to Commvault and do administrative tasks.\
>     The secret is saved in KeyVault: `WeEu-S01-Prd-Kv-Gen-01` Secret: `commvault-script-user`\
>     Use this in your playbook (this is standard in skeleton playbook):\
>       azure_key_vault_url: 'https://weeu-s01-prd-kv-gen-01.vault.azure.net/'\
>       commvault_agent_script_user_password: "{{ lookup('azure_keyvault_secret', 'commvault-script-user', vault_url=azure_key_vault_url) }}"
> * `commvault_agent_settings`
>   * Mandatory: `true`
>   * Type: Dictionary
>   * Description: Contains a list off virtual machines Names with specific variables. 
>
>   * `virtual_machine_name`
>     * Mandatory: `true`
>     * Type: String
>     * Accepted Values: virtual machine name
>     * Description: The name off the virtual machine where the Commvault agent needs to be installed. (CommonName is sufficient. like: weeus03dwdeve01)
>   
>     * `commvault_agent_state`
>       * Mandatory: `true`
>       * Type: String
>       * Accepted Values: present,absent
>       * Description: Property that the agent needs to be installed (present) or deleted (absent)
>   
>     * `commvault_agent_file`
>       * Mandatory: `false`
>       * Type: String
>       * Accepted Values: present
>       * Description: Property that the `file` agent needs to be installed
>   
>     * `commvault_agent_file_locations`
>       * Mandatory: `true` when `commvault_agent_file` is 'present'
>       * Type: Dictionary
>       * Description: paths thats need to be in the backup
>   
>     * `commvault_agent_file_storagepolicy`
>       * Mandatory: `true` when `commvault_agent_file` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off storage policy
>   
>     * `commvault_agent_file_schedulepolicy`
>       * Mandatory: `true` when `commvault_agent_file` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off schedule policy
>   
>     * `commvault_agent_mssql`
>       * Mandatory: `false`
>       * Type: String
>       * Accepted Values: present
>       * Description: Property that the `SQL` agent needs to be installed
>   
>     * `commvault_agent_mssql_instance`
>       * Mandatory: `true` when `commvault_agent_mssql` is 'present'
>       * Type: String
>       * Description: Name off the SQL instance thats needs to be backupt
>   
>     * `commvault_agent_mssql_user`
>       * Mandatory: `true` when `commvault_agent_mssql` is 'present'
>       * Type: String
>       * Description: EMEA Active Directory (service)account that has localadmin rights on the server and proper backup database rights
>   
>     * `commvault_agent_mssql_userpassword`
>       * Mandatory: `true` when `commvault_agent_mssql` is 'present'
>       * Type: String
>       * Description: Password of the 'commvault_agent_mssql_user' This password should be saved in keyvault. and the keyvault should be read here.
>   
>     * `commvault_agent_mssql_storagepolicy_data`
>       * Mandatory: `true` when `commvault_agent_mssql` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off storage policy
>   
>     * `commvault_agent_mssql_storagepolicy_log`
>       * Mandatory: `true` when `commvault_agent_mssql` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off storage policy
>   
>     * `commvault_agent_mssql_schedulepolicy`
>       * Mandatory: `true` when `commvault_agent_mssql` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off schedule policy
>   
>     * `commvault_agent_oracle`
>       * Mandatory: `false`
>       * Type: String
>       * Accepted Values: present
>       * Description: Property that the `ORACLE` agent needs to be installed
>   
>     * `commvault_agent_oracle_instance`
>       * Mandatory: `true` when `commvault_agent_oracle` is 'present'
>       * Type: String
>       * Description: Name off the Oracle instance thats needs to be backupt
>   
>     * `commvault_agent_oracle_storagepolicy_default`
>       * Mandatory: `true` when `commvault_agent_oracle` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off storage policy
>   
>     * `commvault_agent_oracle_storagepolicy_archive`
>       * Mandatory: `true` when `commvault_agent_oracle` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off storage policy
>   
>     * `commvault_agent_oracle_schedulepolicy_default`
>       * Mandatory: `true` when `commvault_agent_oracle` is 'present'
>       * Type: String
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off schedule policy
>   
>     * `commvault_agent_oracle_schedulepolicy_archive`
>       * Mandatory: `true` when `commvault_agent_oracle` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off schedule policy
>   
>     * `commvault_agent_mysql`
>       * Mandatory: `false`
>       * Type: String
>       * Accepted Values: present
>       * Description: Property that the `MySql / MariaDB` agent needs to be installed
>   
>     * `commvault_agent_mysql_instance`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: Name of MySQL/MariaDB Instance
>   
>     * `commvault_agent_mysql_binarydirectory`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: Location of MySQL Binaries directory
>   
>     * `commvault_agent_mysql_logdatadirectory`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: Location of MySQL/MariaDB Logs directory
>   
>     * `commvault_agent_mysql_configfile`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: Location of MySQL/MariaDB Config file
>   
>     * `commvault_agent_mysql_sockfile`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: Location of MySQL/MariaDB Sock file
>   
>     * `commvault_agent_mysql_sauser`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: sa username of MySQL/MariaDB instance/database
>   
>     * `commvault_agent_mysql_sauserpassword`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: sa password of MySQL/MariaDB instance/database
>   
>     * `commvault_agent_mysql_unixuser`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Description: Root username of RedHat server
>   
>     * `commvault_agent_mysql_storagepolicy_default`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name of storage policy
>   
>     * `commvault_agent_mysql_storagepolicy_log`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off storage policy
>   
>     * `commvault_agent_mysql_schedulepolicy_default`
>       * Mandatory: `true` when `commvault_agent_mysql` is 'present'
>       * Type: String
>       * Accepted Values: 'see Confluence or Commvault Console'
>       * Description: Name off schedule policy
>   
>     * `commvault_agent_vm_exclude_disk`
>       * Mandatory: `false`
>       * Type: String
>       * Accepted Values: present
>       * Description: Property that `DATA DISKS` needs to be exclued from Commvault Virtual Machine Backup
>   
>     * `disk_name`
>       * Mandatory: `true` when `commvault_agent_vm_exclude_disk` is 'present'
>       * Type: String
>       * Description: Name off data disk. Like the disk is called in Azure.
>   
>     * `region`
>       * Mandatory: `true` when `commvault_agent_vm_exclude_disk` is 'present'
>       * Type: String
>       * Accepted Values: 'westeurope or northeurope'
>       * Description: Region were the Virtual Machine is deployed
>   
>     * `commvault_virtual_machine_backup`
>       * Mandatory: `true` when `commvault_agent_vm_exclude_disk` is 'present'
>       * Type: String
>       * Accepted Values: 'short or long'
>       * Description: Value of the `commvault_virtual_machine_backup` tag in the Azure Portal (on the Virtual Machine object).

Dependencies
------------

This role has two dependencies.
> * The Virual Machine where the agent is installed must be able to communicate to the Commvault Servers. (tcp ports 443, 8400-8410)
> * The Ansible contol host must have access to the Azure File Share Repository and must be mounted to /mnt/library\
> (https://weeus01prdsagen01.file.core.windows.net)

Skeleton Playbook
=================

requirements.yml
----------------
Add the Commvault Repository to your requirements.yml
```yml
- src: 'git+ssh://git@bitbucket-lan.ah.nl:7999/ahitcfar/commvault_agent.git'
  name: commvault_agent
  version: <optional>
```

servers.yml
-----------
Add import role `commvault_agent` to your servers.yml under the section configuring Linux and/or Windows servers.
```yml
# In the following play we're configuring the group 'linux'.
- name: 'Configure the Linux servers'
  hosts: 'linux'
  become: 'yes'
  tasks:

    - name: 'Importing Server Baseline Configuration Role'
      include_role:
        name: 'azure_compute_baseline'
      tags:
        - 'configure_linux'

    - name: 'Importing the Commvault Agent Role'
      import_role:
        name: 'commvault_agent'

# In the following play we're configuring the group 'windows'.
- name: 'Configure the Windows servers'
  hosts: 'windows'
  gather_facts: true
  tasks:

    - name: 'Importing the Server Baseline Role'
      include_role:
        name: 'azure_compute_baseline'
      tags:
        - 'configure_windows'

    - name: 'Importing the Commvault Agent Role'
      import_role:
        name: 'commvault_agent'
```

group_vars > all > xx_commvault.yml
-----------------------------------
Create a Commvault `group_vars` file in the `all` folder. for example `05_commvault.yml`

> The below example will onboard 2 Virtual Machines:
> * Windows:
>   * File Level Backup. Two directories
>   * SQL backup. Whole SQL instance
> * Linux:
>   * File Level Backup. Two directories
>   * Oracle backup. Whole Oracle instance
>   * MySql/MariaDB backup. Whole MySq/MariaDB instance

```yaml
---
## Used for onboarding the Server to Commvault
commvault_agent_script_user_password: "{{ lookup('azure_keyvault_secret', 'commvault-script-user', vault_url=azure_key_vault_url) }}"

commvault_agent_settings:
# weeus03dwdeve01 - westeurope
  - virtual_machine_name: "weeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}w{{ application_shortname | lower }}01"
    commvault_agent_state: 'present'

    ## Used for SQL onboarding the Server to Commvault
    commvault_agent_mssql: 'present'
    commvault_agent_mssql_instance: 'weeus03dwdeve01\SQLEXPRESS'
    commvault_agent_mssql_user: 'emea\pnl09c35'
    commvault_agent_mssql_userpassword: 'Ahold123'
    commvault_agent_mssql_storagepolicy_data: 'SP_WEEU_MSSQL_14D_DEV_01'
    commvault_agent_mssql_storagepolicy_log: 'SP_WEEU_LOG_7D_DEV_01'
    commvault_agent_mssql_schedulepolicy: 'SCHP-SQL-DailyFull-NoIncr-2200'

    ## Used for File level backup onboarding the Server to Commvault
    commvault_agent_file: 'present'
    commvault_agent_file_locations:
      - 'C:\Temp'
      - 'C:\Packages'
    commvault_agent_file_storagepolicy: 'SP_WEEU_FILE_14D_DEV_01'
    commvault_agent_file_schedulepolicy: 'SCHP-FILE-DailySyntFull-HourIncr-2000'

# weeus03dldeve02 - westeurope
  - virtual_machine_name: "weeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}l{{ application_shortname | lower }}02"
    commvault_agent_state: 'present'

    ## Used for Oracle onboarding the Server to Commvault
    commvault_agent_oracle: 'present'
    commvault_agent_oracle_instance: 'dofmw0t'
    commvault_agent_oracle_storagepolicy_default: 'SP_WEEU_ORACLE_14D_DEV_01'
    commvault_agent_oracle_storagepolicy_archive: 'SP_WEEU_LOG_7D_DEV_01'
    commvault_agent_oracle_schedulepolicy_default: 'SCHP-ORACLE-SundayFull-DailyIncr-2100'
    commvault_agent_oracle_schedulepolicy_archive: 'SCHP-ORACLE-NoFull-2HourIncr-0000'

    ## Used for File level backup onboarding the Server to Commvault
    commvault_agent_file: 'present'
    commvault_agent_file_locations:
      - '/opt/commvault'
      - '/tm/commvault'
    commvault_agent_file_storagepolicy: 'SP_WEEU_FILE_14D_DEV_01'
    commvault_agent_file_schedulepolicy: 'SCHP-FILE-DailySyntFull-HourIncr-2000'

# weeus03dlclfo63 - westeurope
  - virtual_machine_name: "weeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}l{{ application_shortname | lower }}63"
    commvault_agent_state: 'present'

    ## Used for MySql onboarding the Server to Commvault
    commvault_agent_mysql: 'absent'
    commvault_agent_mysql_instance: 'mysql'
    commvault_agent_mysql_binarydirectory: '/usr/bin'
    commvault_agent_mysql_logdatadirectory: '/var/log/mariadb'
    commvault_agent_mysql_configfile: '/appl/mysql/etc/my.cnf'
    commvault_agent_mysql_sockfile: '/appl/mysql/mysql.sock'
    commvault_agent_mysql_sauser: 'dba'
    commvault_agent_mysql_sauserpassword: 'ToBeChanged'
    commvault_agent_mysql_unixuser: 'root'
    commvault_agent_mysql_storagepolicy_default: 'SP_WEEU_MYSQL_14D_DEV_01'
    commvault_agent_mysql_storagepolicy_log: 'SP_WEEU_LOG_7D_DEV_01'
    commvault_agent_mysql_schedulepolicy_default: 'SCHP-MYSQL-SundayFull-DailyIncr-2100'

## Used for excluding disk backup in virtual machine Commvault Backup
commvault_agent_vm_exclude_disk:
  - disk_name: "weeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}{{ os_type | first | lower }}{{ application_shortname | lower }}63-datadisk-01"
    region: 'westeurope'
    commvault_virtual_machine_backup: 'Short'
  - disk_name: "weeu{{ subscription_shortname | lower }}{{ environment_shortname | first | lower }}{{ os_type | first | lower }}{{ application_shortname | lower }}63-datadisk-02"
    region: 'westeurope'
    commvault_virtual_machine_backup: 'Short'
```

Author Information
------------------

Team: AH IT Cloud Foundation Team