# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
Nothing Planned.
---

# Releases
> ## [1.1.4] - 2019-10-05
>
> ### Fixed
> * [TCSCLDVPS-1834](https://jira.ah.nl/browse/TCSCLDVPS-1834) - 'always' tag causes 'ansible_os_family' detection problem
> ## [1.1.3] - 2019-11-05 
>
> ### Fixed 
> * [TCSCLDVPS-1758](https://jira.ah.nl/browse/TCSCLDVPS-1758) - Corrected SWAP Filesystem creation logic 
> ## [1.1.2] - 2019-07-12
>
> ### Fixed
> * (no Jira ticket) - Fixed reboot pending check
>
> ## [1.1.1] - 2019-06-14
>
> ### Fixed
> * [TCSCLDVPS-1212](https://jira.ah.nl/browse/TCSCLDVPS-1212) - Corrected OS conditional bug
>
> ## [1.1.0] - 2019-05-17
>
> ### Added
> * [TCSCLDVPS-490](https://jira.ah.nl/browse/TCSCLDVPS-490) - Provide Computer Description
>
> ### Changed
> * [TCSCLDVPS-797](https://jira.ah.nl/browse/TCSCLDVPS-797) - Removed noexec option from /tmp
> * [TCSCLDVPS-1120](https://jira.ah.nl/browse/TCSCLDVPS-1120) - Make final reboot conditional
>
> ## [1.0.1] - 2019-04-22
>
> ### Fixed
> * [TCSCLDVPS-1059](https://jira.ah.nl/browse/TCSCLDVPS-1059) - Renaming NICs results in error
>
> ## [1.0.1] - 2019-04-22
>
> ### Fixed
> * [TCSCLDVPS-1044](https://jira.ah.nl/browse/TCSCLDVPS-1044) - Corrected List Identation
>
> ## [1.0.0] - 2019-02-26
>
> ### Added
> * [TCSCLDVPS-637](https://jira.ah.nl/browse/TCSCLDVPS-637) - Initial Release

[1.0.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.0.0
[1.0.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.0.1
[1.0.2]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.0.2
[1.1.0]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.1.0
[1.1.1]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.1.1
[1.1.2]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.1.2
[1.1.3]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.1.3
[1.1.4]: https://bitbucket.ah.nl/projects/AHITCFAR/repos/azure_compute_baseline/browse?at=1.1.3
