# Ansible Role: azure_compute_baseline

This Ansible Role configures the following items:
__Linux__:

* Disables SELinux
* Disables Firewalld
* Sets minimum password age to 0 days
* Configure Azure Virtual Machine Linux Agent
* Sets the timezone to Europe/Amsterdam
* Expands the OS disk to the maximum size available

__Windows__:

_**Note**: If you want to join a Windows managed Node to Active Directory, you will also need to use the IAM role._
* Cleans up DSC configuration files
* Creates Temp directory
* Ensures that the following PowerShell DSC resources are present:
  * ComputerManagementDsc
  * StorageDsc
  * NetworkingDsc
  * xRemoteDesktopAdmin
  * xPendingReboot
  * xSystemSecurity
* Sets the timezone to Europe/Amsterdam
* Sets the system local to Dutch
* Renames the NIC to Ethernet
* Disables NetBIOS
* Disables IPv6 binding on the NIC
* Disables LMHOSTS Lookup and WINS
* Configures DNS Suffixes
* Network Provider Order
* Maximum Token Size
* Cached Logon is disabled
* Performance is set to best
* Floppy Drive is disabled
* PowerShell Execution Policy is set to RemoteSigned
* Network Level Authentication is set to Secure
* Windows Error Reporting is set to disabled
* Server Manager startup is disabled
* Cipher suite
* Automatic Updates is disabled
* Chocolatey is installed/updated
* Firewall on all profiles is being disabled
* Sets minimum password age to 0 days

# Requirements

n/a

# Role Variables

## Azure Virtual Machine Linux Agent

>  * `resource_disk_swap_size_mb`
>    * Mandatory: true
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable determines the size of the swap file that will be placed on the Azure ephemeral disk.

## Various

>  * `computer_description`
>    * Mandatory: false
>    * Type: String
>    * Accepted Values: free form
>    * Default Value: none
>    * Description: This variable configures the computer description. When the IAM role is being used in combination with this role, then also the description in Active Directory will be set to the same value.

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_preview_modules).

# Author Information

Team: AH IT Cloud Foundation Team
