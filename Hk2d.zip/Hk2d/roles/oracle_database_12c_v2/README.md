# Ansible Role: oracle_database_12c_v2

- [Ansible Role: Oracle_database_12c_v2](#Oracle_database_12c_v2)
- [About this role](#about-this-role)
- [Default Role Behaviour](#default-role-behaviour)
- [When being applied to a Linux Managed Node](#when-being-applied-to-a-linux-managed-node)
- [Requirements](#requirements)
- [Role Variables](#role-variables)
- [Commvault_agent Variables](#commvault_agent-Variables)
- [FileSystem Variables](#FileSystem-Variables)
- [Examples](#examples)
- [Dependencies](#dependencies)
- [Author Information](#Author-Information)

# About this role
This Ansible Role will install orcale_database_12c with the new skeletton.
This role is tested on wuus01planse04 and Azure devops.

__Linux__:
* FileSystem
* Oracle packages
* CIS Hardening

## Default Role Behaviour
If the role is applied Oracle database 12c will be installed on the target host.
You need to at least specify few variables for this please take a look a the example section.

### When being applied to a Linux Managed Node

* A new filesystem for oracle will be created.
* Oracle 12c packages will be installed.
* Database will be configured with default settings defnined in the file and configurations will be moved to new filesystem.
* CIS hardening (Level 1) will be applied to oralce 12c.

# Requirements

- The Ansible Control Node needs to be MSI enabled and needs to have the correct access to the Azure Key Vault in which the secrets are located for joining Active Directory.

- This role must be executed after `iam` role which sets up the Active directory configuration (sssd config).

### Oracledb Variables
> `oracledb_db_name`
> - Mandatory: `true`
> - Type: `List`
> - Description: This List variable contains database name.
>
> `azure_key_vault_url_okrb:`
> - Mandatory: `true`
> - Type: `List`
> - Description: This List variable contains azure_key_vault_url.
> - Example: azure_key_vault_url_okrb: 'https://weeu-s03-dev-kv-okrb-01.vault.azure.net/'
>
> `wallet_pw:`
> - Mandatory: `true`
> - Type: `List`
> - Description: This List variable contains password for the oracle wallet.
>
> `oracle_pw:`
> - Mandatory: `true`
> - Type: `List`
> - Description: This List variable contains password for the oracle database.
>
> `tdi_pw:`
> - Mandatory: `true`
> - Type: `List`
> - Description: This List variable contains password for the tdi user.
>
> `oracledb_extra_databases`
> - Mandatory: `false`
> - Type: `List`
> - Description: This List variable adds extra databases.
>
### FileSystem Variables

> `oracle_volume_group`
> - Mandatory: `false`
> - Type: `List`
> - Description: This List variable contains details for volume group.
>
>  * `name`
>    * Mandatory: `true` when `oracle_volume_group` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `vg_appl`
>    * Description: This value determines the volume group name.
>
>  * `pvs`
>    * Mandatory: `true` when `oracle_volume_group` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `/dev/sdc`
>    * Description: This variable determines the physical volume name under which volume group will be created. This data disk must exist on the server.
>
> `oracle_logical_volume`
> - Mandatory: `false`
> - Type: `List`
> - Description: This List variable contains details for logical volume.
>
>  * `volume`
>    * Mandatory: `true` when `oracle_logical_volume` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `lv_oracle`
>    * Description: This value determines the logical volume name.
>
>  * `group`
>    * Mandatory: `true` when `oracle_logical_volume` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: value of `oracle_volume_group.name` variable.
>    * Description: This variable determines volume group under which local volume will be mapped.
>
>  * `pvs`
>    * Mandatory: `true` when `oracle_logical_volume` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: value of `oracle_volume_group.pvs` variable.
>    * Description: This variable determines physical volume under which local volume will be mapped.
>
>  * `active`
>    * Mandatory: `true` when `oracle_logical_volume` is defined
>    * Type: `Boolean`
>    * Accepted Values: `true`, `false`
>    * Default Value: `true`
>    * Description: This variable determines whether the volume is activate and visible to the host.
>
>  * `size`
>    * Mandatory: `true` when `oracle_logical_volume` is defined
>    * Type: `String`
>    * Accepted Values: numeric alpha
>    * Default Value: `100G`
>    * Description: This variable determines the size of the logical volume.
>
> `oracle_filesystem`
> - Mandatory: `false`
> - Type: `List`
> - Description: This List variable contains details for filesystem.
>
>  * `fstype`
>    * Mandatory: `true` when `oracle_filesystem` is defined
>    * Type: `String`
>    * Accepted Values: `btrfs`,`ext2`,`ext3`,`ext4`,`ext4dev`,`f2fs`,`lvm`,`ocfs2`,`reiserfs`,`xfs`,`vfat`
>    * Default Value: `xfs`
>    * Description: This value determines filesystem type to be created.
>
>  * `dev`
>    * Mandatory: `true` when `oracle_filesystem` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `/dev/[value of oracle_volume_group.name]/[value of oracle_logical_volume.volume]` variable.
>    * Description: This variable determines target path to device.
>
> `oracle_mount`
> - Mandatory: `false`
> - Type: `List`
> - Description: This List variable contains details for oracle mount point.
>
>  * `name`
>    * Mandatory: `true` when `oracle_mount` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: `/appl/mysql`
>    * Description: This value determines mountpoint name.
>
>  * `src`
>    * Mandatory: `true` when `oracle_mount` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: value of `oracle_filesystem.dev` variable.
>    * Description: This variable determines device to be mounted on path.
>
>  * `fstype`
>    * Mandatory: `true` when `oracle_mount` is defined
>    * Type: `String`
>    * Accepted Values: free form
>    * Default Value: value of `oracle_filesystem.fstype` variable.
>    * Description: This variable determines filesystem type.


# Examples

## Example 1 - oracle_database_12c

```yaml

- name: 'Importing the Oracle_database_12c_v2 Role'
  import_role:
    name: 'oracle_database_12c_v2'
  tags:
   - 'oracle_database_12c_v2'

```
Create a host_vars with your {hostname}.shd.eu.aholddelhaize.com.yml there you will need to put the vairables for the oracle_database_12c_v2 role and commvault_agent role.

## Oracle 12c playbook Vars:
```yaml

oracledb_db_name: 'ORdbTest'
azure_key_vault_url_okrb: 'https://weeu-s03-dev-kv-okrb-01.vault.azure.net/'
wallet_pw: "{{ (lookup('azure_keyvault_secret', 'oracle-database-12c-v2', vault_url=azure_key_vault_url_okrb)) }}"
oracle_pw: "{{ (lookup('azure_keyvault_secret', 'oracle-pw', vault_url=azure_key_vault_url_okrb)) }}"
tdi_pw: "{{ (lookup('azure_keyvault_secret', 'tdi-pw', vault_url=azure_key_vault_url_okrb)) }}"
oracledb_extra_databases:
   - Oracle1
   - Oracle2

```

# Dependencies

This role needs the Ansible Azure module. Albert Heijn IT consumes the Azure Latest modules: [GitHub](https://github.com/Azure/azure_modules).

```
# Make sure you create 3 data disks this is needed by this role.
# Check confluence for size options.
# Depends on datadisk size per machine type.
# @link https://confluence.ah.nl/display/AIF/Design+Oracle+RDBMS#DesignOracleRDBMS-Storagesetup
# Note, do -1 GB per disk for meta stuff to fit in

Important Defaults:

oracledb_orareco_size: '22G'
oracledb_oradata_size: '49G'
```
# Author Information
- Name: Jelle de Bruin
- Email: jelle.bruin.de@ah.nl

- Name: Jesse Mirza
- Email: jesse.mirza@ah.nl
