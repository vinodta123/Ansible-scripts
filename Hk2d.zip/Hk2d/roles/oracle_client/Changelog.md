# Changelog
All notable changes to this Ansible Role will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this Ansible Role adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


# Releases
## 1.0.1 - 2019-09-18
## 1.1.0 - 2019-12-13 [CAP-60](https://jira.ah.nl/browse/CAP-60)


> ### Custom (Feature)
> * [AMIF-67](https://jira.ah.nl/browse/AMIF-67)
>   * New version is compatible with both Azure Devops & Ansible Control Nodes, Variables has to be  defined accordingly under the playbook (Refer README.md for details).
>   * Installation logic has been updated to validate successful  installation of the client  using search_regex and then after proceed further with leftover tasks as currently there was just a wait time defined for n seconds  instead of a check for successful installation

> * [CAP-60](https://jira.ah.nl/browse/CAP-60)
>   * Fix has been done to have local oracle client oraInventory for installaton.
>   * Adding entry to oratab

## 1.0.0 
>
> ### Added - Initial Version


