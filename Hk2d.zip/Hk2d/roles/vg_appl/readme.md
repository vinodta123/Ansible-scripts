***Description***

This will create the base volume group `vg_appl` by default on disk /dev/sdc

***Default variables***

`vg_appl_disk_id: /dev/sdc`
